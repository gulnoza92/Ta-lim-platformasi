import React, { useState } from "react";
import { Brain, Check, Volume2 } from "lucide-react";

export const C = {
  primary: "#028090", secondary: "#00A896", accent: "#02C39A",
  dark: "#03191C", dark2: "#052A2F", bg: "#F5F8F8", muted: "#5B6B6B",
};

export const BADGE_MILESTONES = [
  { at: 1, name: "Birinchi qadam" },
  { at: 5, name: "Faol ishtirokchi" },
  { at: 15, name: "Barqaror o'quvchi" },
  { at: 30, name: "Ilm yulduzi" },
];

export function GlobalFX() {
  return (
    <style>{`
      @keyframes floatOrb { 0%,100% { transform: translate(0,0) scale(1);} 50%{ transform: translate(18px,-24px) scale(1.05);} }
      @keyframes floatOrbSlow { 0%,100% { transform: translate(0,0);} 50%{ transform: translate(-22px,20px);} }
      @keyframes spinSlow { from{transform:rotate(0deg);} to{transform:rotate(360deg);} }
      @keyframes spinSlowReverse { from{transform:rotate(360deg);} to{transform:rotate(0deg);} }
      @keyframes fadeSlideUp { from{opacity:0; transform:translateY(14px);} to{opacity:1; transform:translateY(0);} }
      @keyframes popIn { 0%{transform:scale(0.85); opacity:0;} 100%{transform:scale(1); opacity:1;} }
      @keyframes pulseRing { 0%{box-shadow:0 0 0 0 rgba(2,195,154,0.55);} 70%{box-shadow:0 0 0 14px rgba(2,195,154,0);} 100%{box-shadow:0 0 0 0 rgba(2,195,154,0);} }
      @keyframes shimmer { 0%{background-position:-200% 0;} 100%{background-position:200% 0;} }
      @keyframes spin { to { transform: rotate(360deg); } }
      .fx-fade-up{animation:fadeSlideUp .5s cubic-bezier(.22,1,.36,1) both;}
      .fx-pop{animation:popIn .35s cubic-bezier(.34,1.56,.64,1) both;}
      .fx-pulse{animation:pulseRing 2.2s infinite;}
      .fx-orbit-1{animation:spinSlow 18s linear infinite; transform-origin:center;}
      .fx-orbit-2{animation:spinSlowReverse 26s linear infinite; transform-origin:center;}
      .fx-shimmer{background:linear-gradient(110deg, transparent 40%, rgba(255,255,255,0.5) 50%, transparent 60%); background-size:200% 100%; animation:shimmer 2.6s infinite;}
      .fx-card-hover{transition:transform .25s cubic-bezier(.22,1,.36,1), box-shadow .25s ease, border-color .25s ease;}
      .fx-card-hover:hover{transform:translateY(-3px); box-shadow:0 12px 30px -12px rgba(2,42,47,0.25); border-color:rgba(2,128,144,0.35);}
      .fx-btn{transition:transform .15s ease, box-shadow .2s ease, background-color .2s ease;}
      .fx-btn:hover{transform:translateY(-1px);}
      .fx-btn:active{transform:translateY(0) scale(0.97);}
      .fx-spin{animation:spin 1s linear infinite;}
      .inp{width:100%;padding:0.625rem 0.75rem;border-radius:0.5rem;border:1px solid #e2e8f0;font-size:0.875rem;}
    `}</style>
  );
}

export function AmbientBG() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      <div className="absolute rounded-full blur-3xl opacity-40" style={{ width: 480, height: 480, top: -160, right: -120, background: C.primary, animation: "floatOrb 9s ease-in-out infinite" }} />
      <div className="absolute rounded-full blur-3xl opacity-30" style={{ width: 380, height: 380, bottom: -140, left: -100, background: C.secondary, animation: "floatOrbSlow 11s ease-in-out infinite" }} />
    </div>
  );
}

export function KnowledgeOrbit({ size = 180 }) {
  const s = size, c = s / 2;
  return (
    <div style={{ width: s, height: s }} className="relative shrink-0">
      <svg width={s} height={s} viewBox={`0 0 ${s} ${s}`} className="absolute inset-0">
        <circle cx={c} cy={c} r={c - 4} fill="none" stroke="rgba(2,195,154,0.15)" strokeWidth="1" />
        <circle cx={c} cy={c} r={c * 0.72} fill="none" stroke="rgba(0,168,150,0.18)" strokeWidth="1" />
        <circle cx={c} cy={c} r={c * 0.42} fill="none" stroke="rgba(2,128,144,0.22)" strokeWidth="1" />
      </svg>
      <div className="absolute inset-0 fx-orbit-1"><div className="absolute rounded-full" style={{ width: 10, height: 10, top: 4, left: c - 5, background: C.accent, boxShadow: `0 0 12px ${C.accent}` }} /></div>
      <div className="absolute inset-0 fx-orbit-2"><div className="absolute rounded-full" style={{ width: 8, height: 8, top: c * 0.28 - 4, left: c * 1.72 - 4, background: C.secondary, boxShadow: `0 0 8px ${C.secondary}` }} /></div>
      <div className="absolute rounded-full flex items-center justify-center fx-pulse" style={{ width: s * 0.32, height: s * 0.32, top: c - (s * 0.32) / 2, left: c - (s * 0.32) / 2, background: `radial-gradient(circle at 35% 30%, #0d3f45, ${C.dark})`, border: "1px solid rgba(2,195,154,0.4)" }}>
        <Brain size={s * 0.13} color={C.accent} strokeWidth={1.6} />
      </div>
    </div>
  );
}

export function Pill({ children, tone = "neutral" }) {
  const tones = {
    neutral: "bg-slate-100 text-slate-600", good: "bg-emerald-50 text-emerald-700",
    warn: "bg-amber-50 text-amber-700", pending: "bg-teal-50 text-teal-700",
  };
  return <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${tones[tone]}`}>{children}</span>;
}

export function NavItem({ icon: Icon, label, active, onClick }) {
  return (
    <button onClick={onClick} className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors"
      style={{ color: active ? "#fff" : "rgba(220,240,238,0.62)", background: active ? "rgba(2,128,144,0.4)" : "transparent" }}>
      <Icon size={18} strokeWidth={2} />{label}
    </button>
  );
}

export function useToasts() {
  const [toasts, setToasts] = useState([]);
  function push(msg, tone = "ok") {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, msg, tone }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3200);
  }
  return { toasts, push };
}

export function ToastStack({ toasts }) {
  return (
    <div className="fixed top-5 right-5 z-50 flex flex-col gap-2 items-end">
      {toasts.map((t) => (
        <div key={t.id} className="fx-pop px-4 py-2.5 rounded-xl shadow-lg text-sm font-semibold text-white flex items-center gap-2"
          style={{ background: t.tone === "error" ? "#B91C1C" : C.primary }}>
          {t.tone === "error" ? "!" : <Check size={15} />} {t.msg}
        </div>
      ))}
    </div>
  );
}

function speak(text) {
  try {
    if (typeof window === "undefined" || !window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.rate = 0.95;
    window.speechSynthesis.speak(u);
  } catch { /* browser without speech synthesis */ }
}

export function SpeakButton({ text }) {
  return (
    <button onClick={() => speak(text)} title="Ovozli o'qish"
      className="fx-btn shrink-0 w-8 h-8 rounded-full flex items-center justify-center border border-slate-200 text-slate-400 hover:text-teal-600 hover:border-teal-300">
      <Volume2 size={14} />
    </button>
  );
}
