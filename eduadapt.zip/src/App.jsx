import React, { useState, useEffect, useCallback } from "react";
import {
  Brain, BookOpen, CheckSquare, BarChart3, ChevronRight, RefreshCw, LogOut,
  MapPin, Award, Home, UserCheck, Globe2, Menu, X, Users, ListChecks,
} from "lucide-react";
import { C, GlobalFX, KnowledgeOrbit, NavItem, ToastStack, useToasts } from "./ui.jsx";
import { api, clearToken, getToken, ApiError } from "./lib/api.js";
import AuthGate from "./views/Auth.jsx";
import {
  TeacherContent, TeacherAssessment, TeacherAnalytics, EngagementHub,
  TeacherHomeLearning, TeacherProfessionalDev, TeacherAttendance,
} from "./views/Teacher.jsx";
import {
  StudentQuiz, StudentAssess, StudentBadges, StudentHomeLearning,
} from "./views/Student.jsx";
import { ParentDashboard, AdminDashboard } from "./views/Parent.jsx";
import { TeacherRoster, TeacherQuizBank } from "./views/Roster.jsx";

const TEACHER_TABS = [
  { id: "roster", label: "Sinf ro'yxati", icon: Users },
  { id: "content", label: "Kontent yaratish", icon: BookOpen },
  { id: "quizbank", label: "Test savollari", icon: ListChecks },
  { id: "assess", label: "Baholash", icon: CheckSquare },
  { id: "analytics", label: "Sinf analitikasi", icon: BarChart3 },
  { id: "attendance", label: "Davomat va ota-onalar", icon: UserCheck },
  { id: "engagement", label: "Jalb qilish markazi", icon: MapPin },
  { id: "home", label: "Uyda ta'lim", icon: Home },
  { id: "cpd", label: "Malaka oshirish", icon: Award },
];

const STUDENT_TABS = [
  { id: "quiz", label: "Adaptiv test", icon: Brain },
  { id: "assess", label: "Yozma javob", icon: CheckSquare },
  { id: "badges", label: "Yutuqlarim", icon: Award },
  { id: "home", label: "Uyda ta'lim", icon: Home },
];

export default function App() {
  const [session, setSession] = useState(null);
  const [cls, setCls] = useState(null);
  const [tab, setTab] = useState("content");
  const [loading, setLoading] = useState(false);
  const [navOpen, setNavOpen] = useState(false);
  const { toasts, push } = useToasts();

  function logout() {
    clearToken();
    setSession(null);
    setCls(null);
  }

  /** Every mutation returns the fresh class view, so state stays in sync. */
  const apply = useCallback((next) => { if (next) setCls(next); }, []);

  const refresh = useCallback(async () => {
    if (!session?.classCode) return;
    setLoading(true);
    try {
      setCls(await api.getClass(session.classCode));
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) {
        push("Sessiya tugadi, qayta kiring", "error");
        logout();
      } else {
        push(e.message, "error");
      }
    }
    setLoading(false);
  }, [session, push]);

  function handleEnter(s) {
    setSession(s);
    if (s.initialClass) setCls(s.initialClass);
    setTab(s.role === "teacher" ? "roster" : "quiz");
  }

  // Poll so a student sees new lessons and a teacher sees new submissions
  // without a manual refresh.
  useEffect(() => {
    if (!session?.classCode || !getToken()) return;
    const id = setInterval(refresh, 30000);
    return () => clearInterval(id);
  }, [session, refresh]);

  if (!session) return <><GlobalFX /><AuthGate onEnter={handleEnter} /></>;

  const shared = { cls, code: session.classCode, name: session.name, apply, refresh, toast: push };

  if (session.role === "admin") {
    return (
      <div className="min-h-screen font-sans" style={{ background: C.bg }}>
        <GlobalFX /><ToastStack toasts={toasts} />
        <header className="bg-white border-b border-slate-200 px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3"><KnowledgeOrbit size={34} /><p className="font-serif text-base font-bold text-slate-800">EduAdapt — Admin paneli</p></div>
          <button onClick={logout} className="fx-btn flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-500 border border-slate-200"><LogOut size={13} /> Chiqish</button>
        </header>
        <AdminDashboard adminName={session.name} toast={push} />
      </div>
    );
  }

  if (!cls) {
    return (
      <>
        <GlobalFX />
        <div className="min-h-screen flex flex-col items-center justify-center gap-4" style={{ background: C.bg }}>
          <RefreshCw className="fx-spin text-teal-600" size={22} />
          <p className="text-sm text-slate-500">Sinf ma'lumotlari yuklanmoqda…</p>
          <button onClick={refresh} className="fx-btn px-4 py-2 rounded-lg border border-slate-200 text-xs font-semibold text-slate-600">Qayta urinish</button>
          <button onClick={logout} className="text-xs text-slate-400 underline">Boshiga qaytish</button>
        </div>
      </>
    );
  }

  if (session.role === "parent") {
    return (
      <div className="min-h-screen font-sans" style={{ background: C.bg }}>
        <GlobalFX /><ToastStack toasts={toasts} />
        <header className="bg-white border-b border-slate-200 px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3"><KnowledgeOrbit size={34} /><p className="font-serif text-base font-bold text-slate-800">EduAdapt — Ota-ona paneli</p></div>
          <button onClick={logout} className="fx-btn flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-500 border border-slate-200"><LogOut size={13} /> Chiqish</button>
        </header>
        <ParentDashboard {...shared} childName={session.childName} />
      </div>
    );
  }

  const isTeacher = session.role === "teacher";
  const tabs = isTeacher ? TEACHER_TABS : STUDENT_TABS;

  return (
    <div className="min-h-screen md:flex font-sans" style={{ background: C.bg }}>
      <GlobalFX />
      <ToastStack toasts={toasts} />

      {/* Mobile top bar — the sidebar is off-canvas below md */}
      <header className="md:hidden sticky top-0 z-30 flex items-center justify-between px-4 py-3" style={{ background: C.dark }}>
        <div className="flex items-center gap-2">
          <KnowledgeOrbit size={28} />
          <div>
            <p className="text-white font-serif text-sm font-bold leading-none">EduAdapt</p>
            <p className="text-teal-100/40 text-[10px] mt-0.5">{tabs.find((t) => t.id === tab)?.label}</p>
          </div>
        </div>
        <button onClick={() => setNavOpen(true)} aria-label="Menyu"
          className="w-9 h-9 rounded-lg flex items-center justify-center text-white/70 border border-white/15">
          <Menu size={18} />
        </button>
      </header>

      {navOpen && <div className="md:hidden fixed inset-0 bg-black/50 z-40" onClick={() => setNavOpen(false)} />}

      <aside className={`w-64 shrink-0 p-5 flex flex-col gap-1 z-50 transition-transform
        fixed inset-y-0 left-0 overflow-y-auto md:static md:translate-x-0
        ${navOpen ? "translate-x-0" : "-translate-x-full"}`} style={{ background: C.dark }}>
        <div className="mb-6 px-2 flex items-center gap-3">
          <KnowledgeOrbit size={38} />
          <div className="flex-1">
            <p className="text-white font-serif text-lg font-bold leading-none">EduAdapt</p>
            <p className="text-teal-100/40 text-[10px] mt-1">{cls.name}</p>
          </div>
          <button onClick={() => setNavOpen(false)} aria-label="Yopish" className="md:hidden text-white/50"><X size={18} /></button>
        </div>

        <div className="px-3 py-2 mb-3 rounded-lg bg-white/5 border border-white/10">
          <p className="text-[10px] text-teal-100/40 uppercase tracking-wider">{isTeacher ? "O'qituvchi" : "O'quvchi"}</p>
          <p className="text-sm text-white font-medium">{session.name}</p>
          {isTeacher && <p className="text-[10px] text-teal-300/70 font-mono mt-1">Sinf kodi: {session.classCode}</p>}
        </div>

        {tabs.map((t) => (
          <NavItem key={t.id} icon={t.icon} label={t.label} active={tab === t.id}
            onClick={() => { setTab(t.id); setNavOpen(false); }} />
        ))}

        <button onClick={refresh} className="w-full flex items-center gap-3 px-4 py-2.5 mt-2 rounded-xl text-xs font-medium text-teal-100/50 hover:text-white">
          <RefreshCw size={14} className={loading ? "fx-spin" : ""} /> Yangilash
        </button>

        <div className="mt-auto px-2 pt-4 border-t border-white/10">
          <button onClick={logout} className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs text-teal-100/50 hover:text-white"><LogOut size={14} /> Chiqish</button>
          <p className="text-[10px] text-teal-100/30 mt-3 flex items-center gap-1"><Globe2 size={11} /> AI-adaptiv ta'lim platformasi</p>
        </div>
      </aside>

      <main className="flex-1 p-4 sm:p-8 lg:p-10 max-w-5xl w-full">
        <div className="hidden md:flex items-center gap-2 text-sm text-slate-400 mb-6">
          <span>{cls.name}</span><ChevronRight size={14} />
          <span className="text-slate-700 font-medium">{tabs.find((t) => t.id === tab)?.label}</span>
        </div>

        <div key={tab}>
          {isTeacher && tab === "roster" && <TeacherRoster {...shared} />}
          {isTeacher && tab === "quizbank" && <TeacherQuizBank {...shared} />}
          {isTeacher && tab === "content" && <TeacherContent {...shared} />}
          {isTeacher && tab === "assess" && <TeacherAssessment {...shared} />}
          {isTeacher && tab === "analytics" && <TeacherAnalytics cls={cls} />}
          {isTeacher && tab === "attendance" && <TeacherAttendance {...shared} />}
          {isTeacher && tab === "engagement" && <EngagementHub {...shared} />}
          {isTeacher && tab === "home" && <TeacherHomeLearning {...shared} />}
          {isTeacher && tab === "cpd" && <TeacherProfessionalDev {...shared} />}

          {!isTeacher && tab === "quiz" && <StudentQuiz {...shared} />}
          {!isTeacher && tab === "assess" && <StudentAssess {...shared} />}
          {!isTeacher && tab === "badges" && <StudentBadges cls={cls} name={session.name} />}
          {!isTeacher && tab === "home" && <StudentHomeLearning {...shared} />}
        </div>
      </main>
    </div>
  );
}
