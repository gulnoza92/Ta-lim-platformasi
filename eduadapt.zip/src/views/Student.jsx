import React, { useState, useEffect, useCallback } from "react";
import { Star, Home, Send, MapPin, GraduationCap, Type, Volume2, Clock, HeartPulse, RefreshCw, Sparkles } from "lucide-react";
import { C, AmbientBG, Pill, SpeakButton, BADGE_MILESTONES } from "../ui.jsx";
import { api, parseJsonLoose } from "../lib/api.js";

/* ============================ Adaptive quiz ============================ */
/* Questions come from the class's own bank, and the server marks them —
   the correct answer is never sent to the browser before the guess. */
const LEVELS = ["oson", "orta", "qiyin"];

export function StudentQuiz({ cls, code, name, refresh, toast }) {
  const [level, setLevel] = useState("orta");
  const [q, setQ] = useState(null);
  const [result, setResult] = useState(null);
  const [selected, setSelected] = useState(null);
  const [loading, setLoading] = useState(true);
  const [empty, setEmpty] = useState(false);

  const mastery = cls.students[name]?.mastery ?? 50;

  const load = useCallback(async (lv) => {
    setLoading(true); setResult(null); setSelected(null);
    try {
      setQ(await api.nextQuizQuestion(code, lv));
      setEmpty(false);
    } catch (e) {
      if (e.status === 404) setEmpty(true); else toast(e.message, "error");
    }
    setLoading(false);
  }, [code, toast]);

  useEffect(() => { load(level); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, []);

  async function answer(choice) {
    if (result || !q) return;
    setSelected(choice);
    try {
      const r = await api.answerQuiz(code, q.id, choice);
      setResult(r);
      await refresh();
      setTimeout(() => {
        let idx = LEVELS.indexOf(level);
        if (r.correct && r.mastery > 65) idx = Math.min(2, idx + 1);
        if (!r.correct && r.mastery < 40) idx = Math.max(0, idx - 1);
        const next = LEVELS[idx];
        setLevel(next);
        load(next);
      }, 1200);
    } catch (e) { toast(e.message, "error"); setSelected(null); }
  }

  const levelLabel = { oson: "Oson", orta: "O'rta", qiyin: "Qiyin" };
  const levelColor = { oson: C.secondary, orta: C.primary, qiyin: C.dark };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-5 gap-6 fx-fade-up">
      <div className="lg:col-span-3 bg-white rounded-2xl border border-slate-200 p-5 sm:p-7">
        <div className="flex items-center justify-between mb-6">
          <div>
            <p className="text-xs uppercase tracking-wider text-slate-400 font-semibold">{cls.subject}</p>
            <h3 className="text-lg font-semibold text-slate-800 mt-0.5">Adaptiv diagnostika</h3>
          </div>
          <span key={level} className="fx-pop px-3 py-1.5 rounded-full text-xs font-bold text-white" style={{ background: levelColor[level] }}>
            {levelLabel[level]} daraja
          </span>
        </div>

        {empty ? (
          <p className="text-sm text-slate-400 italic py-8 text-center">
            Bu sinfda hali test savoli yo'q. O'qituvchingiz savol qo'shgach, shu yerda paydo bo'ladi.
          </p>
        ) : loading || !q ? (
          <div className="flex items-center gap-2 text-slate-400 text-sm py-8 justify-center">
            <RefreshCw size={14} className="fx-spin" /> Savol yuklanmoqda…
          </div>
        ) : (
          <>
            <p key={q.id} className="fx-fade-up text-xl sm:text-2xl font-serif text-slate-800 mb-6 flex items-start gap-3">
              <span>{q.question}</span><SpeakButton text={q.question} />
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {q.options.map((opt) => {
                const isCorrect = result && opt === result.correctAnswer;
                const isWrong = result && selected === opt && !result.correct;
                return (
                  <button key={opt} onClick={() => answer(opt)} disabled={!!result}
                    className={`fx-btn px-4 py-3 rounded-xl border text-sm font-medium text-left ${isCorrect ? "bg-emerald-50 border-emerald-400 text-emerald-700" : isWrong ? "bg-rose-50 border-rose-300 text-rose-600" : "border-slate-200 text-slate-700 hover:border-teal-400 hover:bg-teal-50/40"}`}>
                    {opt}
                  </button>
                );
              })}
            </div>
            {result && (
              <p className={`fx-fade-up mt-4 text-sm font-semibold ${result.correct ? "text-emerald-600" : "text-rose-500"}`}>
                {result.correct ? "To'g'ri! Qiyinchilik moslashtirilmoqda…" : `Xato. To'g'ri javob: ${result.correctAnswer}`}
              </p>
            )}
          </>
        )}
        <p className="mt-6 text-xs text-slate-400">Natijalaringiz serverda saqlanadi — o'qituvchingiz buni ko'radi.</p>
      </div>

      <div className="lg:col-span-2 rounded-2xl p-7 text-white relative overflow-hidden" style={{ background: `linear-gradient(155deg, ${C.dark2}, ${C.dark})` }}>
        <AmbientBG />
        <div className="relative">
          <p className="text-xs uppercase tracking-wider text-teal-300/70 font-semibold mb-1">Sizning bilim darajangiz</p>
          <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden mt-4">
            <div className="h-full rounded-full transition-all duration-500" style={{ width: `${mastery}%`, background: C.accent }} />
          </div>
          <p className="text-3xl font-bold mt-3">{mastery}%</p>
          <p className="text-xs text-teal-100/60">Bu ko'rsatkich o'qituvchingiz panelida ham ko'rinadi</p>
        </div>
      </div>
    </div>
  );
}

/* ============================ Open answer ============================ */
export function StudentAssess({ cls, code, name, apply, toast }) {
  const [qid, setQid] = useState(cls.openQuestions[0]?.id ?? "");
  const [answer, setAnswer] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit() {
    if (!answer.trim()) return;
    const q = cls.openQuestions.find((x) => String(x.id) === String(qid));
    if (!q) return toast("Savol tanlanmagan", "error");
    setLoading(true);
    try {
      const raw = await api.ask(
        `Sen o'qituvchi yordamchisisan. Savol: "${q.text}" Talaba javobi: "${answer}". 0-10 oralig'ida baho ber, qisqa izoh yoz va bitta yo'naltiruvchi savol ber (javobni aytmasdan). Faqat JSON: {"score": 0, "feedback": "...", "guidingQuestion": "..."}`
      );
      const p = parseJsonLoose(raw) || { score: null, feedback: "AI izoh bera olmadi.", guidingQuestion: "" };
      apply(await api.submitAnswer(code, {
        questionId: q.id, answer, aiScore: p.score, aiNote: p.feedback, guidingQuestion: p.guidingQuestion,
      }));
      setAnswer("");
      toast("Javobingiz yuborildi — o'qituvchi tasdiqlaydi");
    } catch (e) { toast(e.message, "error"); }
    setLoading(false);
  }

  const mySubs = cls.submissions.filter((s) => s.student === name);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 fx-fade-up">
      <div className="bg-white rounded-2xl border border-slate-200 p-6">
        <p className="text-xs uppercase tracking-wider text-slate-400 font-semibold mb-4">Yozma javob topshirish</p>
        <div className="flex items-center gap-2 mb-3">
          <select value={qid} onChange={(e) => setQid(e.target.value)} className="inp bg-white">
            {cls.openQuestions.map((q) => <option key={q.id} value={q.id}>{q.text}</option>)}
          </select>
          <SpeakButton text={cls.openQuestions.find((x) => String(x.id) === String(qid))?.text || ""} />
        </div>
        <textarea value={answer} onChange={(e) => setAnswer(e.target.value)} rows={5} placeholder="Javobingizni shu yerga yozing…" className="inp mb-3" />
        <button onClick={submit} disabled={loading} className="fx-btn relative overflow-hidden flex items-center gap-2 px-4 py-2.5 rounded-lg text-white text-sm font-semibold disabled:opacity-70" style={{ background: C.primary }}>
          {loading && <span className="absolute inset-0 fx-shimmer" />}
          <Sparkles size={16} /> {loading ? "AI baholamoqda…" : "Yuborish"}
        </button>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-6">
        <p className="text-xs uppercase tracking-wider text-slate-400 font-semibold mb-4">Sizning topshiriqlaringiz</p>
        {mySubs.length === 0 ? <p className="text-sm text-slate-400 italic">Hali topshiriq yo'q.</p> : (
          <div className="space-y-3">
            {mySubs.slice().reverse().map((s) => (
              <div key={s.id} className="border border-slate-100 rounded-xl p-4 bg-slate-50">
                <p className="text-sm text-slate-700 mb-1">{s.questionText}</p>
                {s.status === "kutilmoqda"
                  ? <Pill tone="pending">O'qituvchi tekshirmoqda</Pill>
                  : <Pill tone="good">Yakuniy baho: {s.finalScore}/10</Pill>}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

/* ============================ Badges ============================ */
export function StudentBadges({ cls, name }) {
  const eng = cls.students[name]?.engagement || { count: 0, badges: [] };
  const next = BADGE_MILESTONES.find((m) => m.at > eng.count);
  return (
    <div className="fx-fade-up">
      <p className="text-xs uppercase tracking-wider text-slate-400 font-semibold mb-1">Yutuqlarim</p>
      <h3 className="text-lg font-semibold text-slate-800 mb-5">Har bir faoliyat sizni bir qadam yaqinlashtiradi</h3>

      <div className="bg-white rounded-2xl border border-slate-200 p-6 mb-4">
        <p className="text-sm text-slate-500 mb-3">Jami faoliyat: <span className="font-bold text-teal-600">{eng.count}</span></p>
        <div className="flex gap-3 flex-wrap">
          {BADGE_MILESTONES.map((m) => {
            const earned = eng.badges.includes(m.name);
            return (
              <div key={m.name} className={`flex flex-col items-center gap-1.5 px-4 py-3 rounded-xl border ${earned ? "border-amber-300 bg-amber-50" : "border-slate-200 bg-slate-50 opacity-50"}`}>
                <Star size={20} className={earned ? "text-amber-500" : "text-slate-300"} />
                <p className="text-xs font-semibold text-slate-700 text-center">{m.name}</p>
              </div>
            );
          })}
        </div>
        {next && <p className="text-xs text-slate-400 mt-4">Keyingi nishon "{next.name}" uchun yana {next.at - eng.count} ta faoliyat kerak.</p>}
      </div>

      <div className="rounded-2xl p-6 text-white relative overflow-hidden mb-4" style={{ background: `linear-gradient(155deg, ${C.dark2}, ${C.dark})` }}>
        <AmbientBG />
        <div className="relative flex items-center gap-3">
          <MapPin size={18} className="text-teal-300 shrink-0" />
          <p className="text-sm text-teal-50/90">
            Hududingizdagi murabbiy: <b>{cls.hub?.mentor || "hali tayinlanmagan"}</b>
            {cls.hub?.mobileLabNext ? ` · Keyingi mobil laboratoriya: ${cls.hub.mobileLabNext}` : ""}
          </p>
        </div>
      </div>

      <div className="rounded-2xl p-6 border border-indigo-200 bg-indigo-50">
        <div className="flex items-center gap-2 mb-2">
          <GraduationCap size={16} className="text-indigo-600" />
          <p className="text-sm font-semibold text-indigo-800">Tadqiqot imkoniyati</p>
        </div>
        <p className="text-sm text-indigo-700/90 leading-relaxed">
          Maktab o'quvchilari uchun xalqaro tadqiqot dasturlari mavjud — mentor bilan birga mustaqil ilmiy maqola yozish imkoniyati.
          O'qituvchingizdan batafsil so'rang.
        </p>
      </div>
    </div>
  );
}

/* ============================ Home learning ============================ */
const ACCOMMODATIONS = [
  { key: "largeText", label: "Katta shrift / ko'proq oraliq", icon: Type },
  { key: "audioHelp", label: "Ovozli o'qish yordami", icon: Volume2 },
  { key: "extraTime", label: "Vazifalar uchun qo'shimcha vaqt", icon: Clock },
  { key: "reducedLoad", label: "Kamaytirilgan haftalik yuklama", icon: HeartPulse },
];

export function StudentHomeLearning({ cls, code, name, apply, toast }) {
  const home = cls.students[name]?.home || { active: false, note: "", duration: "vaqtinchalik", accommodations: {}, checkIns: [] };
  const acc = home.accommodations || {};
  const [msg, setMsg] = useState("");

  async function save(patch) {
    try { apply(await api.updateHome(code, patch)); }
    catch (e) { toast(e.message, "error"); }
  }
  async function sendCheckIn() {
    if (!msg.trim()) return;
    try { apply(await api.sendCheckIn(code, msg)); setMsg(""); toast("O'qituvchiga xabar yuborildi"); }
    catch (e) { toast(e.message, "error"); }
  }

  return (
    <div className={`fx-fade-up max-w-2xl ${acc.largeText ? "text-lg" : ""}`}>
      <p className="text-xs uppercase tracking-wider text-slate-400 font-semibold mb-1">Uyda ta'lim</p>
      <h3 className={`font-semibold text-slate-800 mb-2 ${acc.largeText ? "text-2xl" : "text-lg"}`}>Bosim yo'q — o'z sur'atingizda</h3>
      <p className="text-sm text-slate-500 mb-5">Qisqa muddat uchun ham, uzoq muddatli uyda ta'lim uchun ham mo'ljallangan.</p>

      <div className="bg-white rounded-2xl border border-slate-200 p-6 mb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2"><Home size={16} className="text-teal-600" /><p className="text-sm font-semibold text-slate-800">Uyda ta'lim rejimi</p></div>
          <button onClick={() => save({ active: !home.active, accommodations: acc, duration: home.duration })}
            className="fx-btn px-4 py-2 rounded-lg text-sm font-semibold"
            style={{ background: home.active ? "#FEE2E2" : C.primary, color: home.active ? "#B91C1C" : "#fff" }}>
            {home.active ? "O'chirish" : "Yoqish"}
          </button>
        </div>
        <p className="text-xs text-slate-400 mt-2">Yoqilganda o'qituvchingiz sizga alohida reja tuzadi.</p>
        {home.note && <p className="text-sm text-teal-700 bg-teal-50 rounded-lg px-3 py-2 mt-3 border border-teal-100">O'qituvchi rejasi: {home.note}</p>}
      </div>

      {home.active && (
        <>
          <div className="bg-white rounded-2xl border border-slate-200 p-6 mb-4">
            <p className="text-xs uppercase tracking-wider text-slate-400 font-semibold mb-3">Bu vaqtinchalikmi yoki uzoq muddatlimi?</p>
            <div className="flex gap-2 mb-5">
              {[["vaqtinchalik", "Vaqtinchalik"], ["uzoq_muddatli", "Uzoq muddatli"]].map(([v, label]) => (
                <button key={v} onClick={() => save({ active: true, duration: v, accommodations: acc })}
                  className={`fx-btn flex-1 px-3 py-2 rounded-lg text-sm font-medium border ${home.duration === v ? "border-teal-400 bg-teal-50 text-teal-700" : "border-slate-200 text-slate-500"}`}>
                  {label}
                </button>
              ))}
            </div>

            <p className="text-xs uppercase tracking-wider text-slate-400 font-semibold mb-3">Sizga kerakli moslashtirishlar</p>
            <div className="grid grid-cols-2 gap-2">
              {ACCOMMODATIONS.map((a) => (
                <button key={a.key} onClick={() => save({ active: true, duration: home.duration, accommodations: { ...acc, [a.key]: !acc[a.key] } })}
                  className={`fx-btn flex items-center gap-2 px-3 py-2.5 rounded-lg border text-xs font-medium text-left ${acc[a.key] ? "border-teal-400 bg-teal-50 text-teal-700" : "border-slate-200 text-slate-500"}`}>
                  <a.icon size={14} /> {a.label}
                </button>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 p-6">
            <p className="text-xs uppercase tracking-wider text-slate-400 font-semibold mb-3">O'qituvchiga xabar</p>
            <div className="flex gap-2">
              <input value={msg} onChange={(e) => setMsg(e.target.value)} placeholder="Masalan: bugun dam olsam bo'ladimi?" className="inp" />
              <button onClick={sendCheckIn} className="fx-btn flex items-center gap-1.5 px-4 py-2.5 rounded-lg text-white text-sm font-semibold shrink-0" style={{ background: C.primary }}>
                <Send size={14} /> Yuborish
              </button>
            </div>
            <p className="text-xs text-slate-400 mt-3">Bu xabar baholashga ta'sir qilmaydi.</p>
          </div>
        </>
      )}
    </div>
  );
}
