import React, { useState } from "react";
import {
  Users, Check, Pencil, AlertTriangle, Sparkles, Plus, HelpCircle, MapPin, Award,
  Bus, Star, Home, UserCheck, MessageCircle, Coffee,
} from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { C, AmbientBG, Pill } from "../ui.jsx";
import { api, parseJsonLoose } from "../lib/api.js";

/* ============================ Content studio ============================ */
export function TeacherContent({ cls, code, apply, toast }) {
  const [title, setTitle] = useState("");
  const [loading, setLoading] = useState(false);

  async function generate() {
    if (!title.trim()) return toast("Avval mavzu nomini kiriting", "error");
    setLoading(true);
    try {
      const raw = await api.ask(`Sen o'zbek tilida ${cls.subject} o'qituvchisisan. "${title}" mavzusi bo'yicha bitta amaliy mashq yoz. Faqat JSON qaytar: {"question": "..."}`);
      const q = parseJsonLoose(raw)?.question || raw.slice(0, 300);
      apply(await api.addLesson(code, { title, body: q, createdBy: "AI + o'qituvchi" }));
      setTitle("");
      toast("Mashq yaratildi va saqlandi");
    } catch (e) { toast(e.message, "error"); }
    setLoading(false);
  }

  async function addManual() {
    if (!title.trim()) return;
    try {
      apply(await api.addLesson(code, { title, body: "(o'qituvchi tomonidan qo'lda kiritilgan)", createdBy: cls.teacher }));
      setTitle("");
      toast("Mashq qo'shildi");
    } catch (e) { toast(e.message, "error"); }
  }

  return (
    <div className="fx-fade-up">
      <p className="text-xs uppercase tracking-wider text-slate-400 font-semibold mb-1">Kontent yaratish — {cls.name}</p>
      <h3 className="text-lg font-semibold text-slate-800 mb-5">O'qituvchi o'zi yaratadi, AI yordam beradi</h3>

      <div className="bg-white rounded-2xl border border-slate-200 p-6 mb-6">
        <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Mavzu nomi (masalan: Kvadrat tenglamalar)" className="inp mb-3" />
        <div className="flex gap-2">
          <button onClick={generate} disabled={loading} className="fx-btn relative overflow-hidden flex items-center gap-2 px-4 py-2.5 rounded-lg text-white text-sm font-semibold disabled:opacity-70" style={{ background: C.primary }}>
            {loading && <span className="absolute inset-0 fx-shimmer" />}
            <Sparkles size={16} /> {loading ? "AI yaratmoqda…" : "AI bilan mashq yaratish"}
          </button>
          <button onClick={addManual} className="fx-btn flex items-center gap-2 px-4 py-2.5 rounded-lg border border-slate-200 text-sm font-semibold text-slate-600">
            <Plus size={16} /> Qo'lda qo'shish
          </button>
        </div>
      </div>

      <div className="space-y-3">
        {cls.content.length === 0 && <p className="text-sm text-slate-400 italic">Hali mashq qo'shilmagan.</p>}
        {cls.content.slice().reverse().map((c) => (
          <div key={c.id} className="fx-card-hover bg-white rounded-2xl border border-slate-200 p-5">
            <div className="flex items-center justify-between mb-1">
              <p className="text-sm font-semibold text-slate-800">{c.title}</p>
              <Pill tone={c.createdBy.includes("AI") ? "pending" : c.createdBy.includes("Namuna") ? "good" : "neutral"}>{c.createdBy}</Pill>
            </div>
            <p className="text-sm text-slate-600">{c.body}</p>
            {c.guidingQuestion && (
              <p className="text-xs text-teal-600 mt-2 flex items-start gap-1.5 border-t border-slate-100 pt-2">
                <HelpCircle size={13} className="mt-0.5 shrink-0" /> Muhokama uchun savol: {c.guidingQuestion}
              </p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ============================ Assessment ============================ */
export function TeacherAssessment({ cls, code, apply, toast }) {
  const [editingId, setEditingId] = useState(null);
  const [draftScore, setDraftScore] = useState("");
  const [draftNote, setDraftNote] = useState("");

  async function grade(id, payload, msg) {
    try { apply(await api.gradeSubmission(code, id, payload)); setEditingId(null); toast(msg); }
    catch (e) { toast(e.message, "error"); }
  }

  const pending = cls.submissions.filter((s) => s.status === "kutilmoqda");
  const done = cls.submissions.filter((s) => s.status !== "kutilmoqda");

  return (
    <div className="fx-fade-up">
      <div className="flex items-center justify-between mb-6">
        <div>
          <p className="text-xs uppercase tracking-wider text-slate-400 font-semibold">Human-in-the-loop baholash</p>
          <h3 className="text-lg font-semibold text-slate-800 mt-0.5">AI taklif qiladi — siz tasdiqlaysiz</h3>
        </div>
        <Pill tone={pending.length > 0 ? "warn" : "good"}>{pending.length} ta kutilmoqda</Pill>
      </div>

      {cls.submissions.length === 0 && <p className="text-sm text-slate-400 italic">Hali javob topshirilmagan.</p>}

      <div className="space-y-4">
        {[...pending, ...done].map((s) => (
          <div key={s.id} className="fx-card-hover bg-white rounded-2xl border border-slate-200 p-6">
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1">
                <p className="text-sm font-semibold text-slate-800">{s.student}</p>
                <p className="text-sm text-slate-500 mt-1">{s.questionText}</p>
                <p className="text-sm text-slate-700 mt-3 bg-slate-50 rounded-lg px-3 py-2 border border-slate-100">{s.answer}</p>
                {s.guidingQuestion && (
                  <p className="text-xs text-teal-600 mt-2 flex items-start gap-1.5"><HelpCircle size={13} className="mt-0.5 shrink-0" /> Yo'naltiruvchi savol: {s.guidingQuestion}</p>
                )}
              </div>
              <div className="w-56 shrink-0">
                <div className="flex items-center gap-2 text-xs font-semibold text-teal-600 mb-1"><Sparkles size={14} /> AI taklifi: {s.aiScore}/10</div>
                <p className="text-xs text-slate-400 leading-relaxed">{s.aiNote}</p>
              </div>
            </div>
            <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between">
              {editingId === s.id ? (
                <div className="flex items-center gap-3 flex-1">
                  <input type="number" min="0" max="10" value={draftScore} onChange={(e) => setDraftScore(e.target.value)} className="w-16 px-2 py-1.5 rounded-lg border border-slate-200 text-sm" />
                  <input type="text" value={draftNote} onChange={(e) => setDraftNote(e.target.value)} className="flex-1 px-3 py-1.5 rounded-lg border border-slate-200 text-sm" />
                  <button onClick={() => grade(s.id, { action: "edit", score: draftScore, note: draftNote }, "O'zgarish saqlandi")} className="fx-btn px-3 py-1.5 rounded-lg text-white text-xs font-semibold" style={{ background: C.primary }}>Saqlash</button>
                </div>
              ) : (
                <>
                  <div>
                    {s.status === "kutilmoqda" && <Pill tone="pending">Kutilmoqda</Pill>}
                    {s.status === "tasdiqlangan" && <Pill tone="good">Tasdiqlangan · {s.finalScore}/10</Pill>}
                    {s.status === "tahrirlangan" && <Pill tone="warn">Tahrirlangan · {s.finalScore}/10</Pill>}
                  </div>
                  {s.status === "kutilmoqda" && (
                    <div className="flex gap-2">
                      <button onClick={() => { setEditingId(s.id); setDraftScore(String(s.aiScore ?? "")); setDraftNote(s.aiNote || ""); }} className="fx-btn flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold text-slate-600"><Pencil size={13} /> Tahrirlash</button>
                      <button onClick={() => grade(s.id, { action: "approve" }, "Baho tasdiqlandi")} className="fx-btn flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-white text-xs font-semibold" style={{ background: C.primary }}><Check size={13} /> Tasdiqlash</button>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ============================ Analytics ============================ */
export function TeacherAnalytics({ cls }) {
  const roster = Object.entries(cls.students).map(([name, d]) => ({ name, mastery: d.mastery }));
  const atRisk = roster.filter((r) => r.mastery < 45);
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 fx-fade-up">
      <div className="bg-white rounded-2xl border border-slate-200 p-6">
        <div className="flex items-center gap-2 mb-4"><Users size={15} className="text-teal-600" /><p className="text-xs uppercase tracking-wider text-slate-400 font-semibold">Sinf ro'yxati — {roster.length} o'quvchi</p></div>
        {roster.length === 0 ? <p className="text-sm text-slate-400 italic">Hali o'quvchi qo'shilmagan. Sinf kodi va parolini ulashing.</p> : (
          <ResponsiveContainer width="100%" height={Math.max(180, roster.length * 40)}>
            <BarChart data={roster} layout="vertical" margin={{ left: 10 }}>
              <CartesianGrid stroke="#eef2f2" horizontal={false} />
              <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 11, fill: C.muted }} axisLine={false} tickLine={false} />
              <YAxis type="category" dataKey="name" tick={{ fontSize: 12, fill: "#334155" }} axisLine={false} tickLine={false} width={90} />
              <Tooltip contentStyle={{ borderRadius: 8, border: "1px solid #e2e8e8", fontSize: 12 }} />
              <Bar dataKey="mastery" radius={[0, 6, 6, 0]} fill={C.primary} />
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>
      <div className="rounded-2xl p-6 text-white relative overflow-hidden" style={{ background: `linear-gradient(155deg, ${C.dark2}, ${C.dark})` }}>
        <AmbientBG />
        <div className="relative">
          <div className="flex items-center gap-2 mb-4"><AlertTriangle size={16} className="text-amber-300" /><p className="text-xs uppercase tracking-wider text-teal-100/70 font-semibold">Erta ogohlantirish</p></div>
          {atRisk.length === 0 ? <p className="text-sm text-teal-100/60">Hozircha xavf ostidagi o'quvchi yo'q.</p> : (
            <div className="space-y-2">
              {atRisk.map((r) => (
                <div key={r.name} className="flex items-center justify-between bg-white/5 rounded-lg px-3 py-2 border border-white/10">
                  <span className="text-sm">{r.name}</span><span className="text-xs text-rose-300 font-semibold">{r.mastery}%</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ============================ Engagement hub ============================ */
export function EngagementHub({ cls, code, apply, toast }) {
  const [mentor, setMentor] = useState(cls.hub?.mentor || "");
  const [nextVisit, setNextVisit] = useState(cls.hub?.mobileLabNext || "");
  const roster = Object.entries(cls.students).map(([name, d]) => ({ name, count: d.engagement.count, badges: d.engagement.badges }));
  const disengaged = roster.filter((r) => r.count === 0);

  async function saveHub() {
    try { apply(await api.updateHub(code, { mentor, mobileLabNext: nextVisit })); toast("Hub ma'lumotlari saqlandi"); }
    catch (e) { toast(e.message, "error"); }
  }

  return (
    <div className="fx-fade-up space-y-6">
      <div>
        <p className="text-xs uppercase tracking-wider text-slate-400 font-semibold mb-1">Jalb qilish markazi</p>
        <h3 className="text-lg font-semibold text-slate-800">Chekka hududlar uchun "Hub-and-spoke" kampus va motivatsiya</h3>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="rounded-2xl p-6 text-white relative overflow-hidden" style={{ background: `linear-gradient(155deg, ${C.dark2}, ${C.dark})` }}>
          <AmbientBG />
          <div className="relative">
            <div className="flex items-center gap-2 mb-4"><MapPin size={16} className="text-teal-300" /><p className="text-xs uppercase tracking-wider text-teal-100/70 font-semibold">Fizik infratuzilma</p></div>
            <p className="text-sm text-teal-50/90 mb-1"><span className="text-teal-300/70">Markaziy kampus:</span> {cls.hub?.hubName || "Belgilanmagan"}</p>
            <div className="flex items-center gap-2 mt-3 mb-1"><Bus size={14} className="text-teal-300" /><p className="text-xs text-teal-100/70">Mobil laboratoriya jadvali</p></div>
            <input value={nextVisit} onChange={(e) => setNextVisit(e.target.value)} placeholder="Masalan: 25-avgust, tuman markazida" className="w-full px-3 py-2 rounded-lg bg-white/10 border border-white/20 text-sm text-white placeholder:text-teal-100/40 mb-3" />
            <p className="text-xs text-teal-100/70 mb-1">Yaqin-tengdosh murabbiy</p>
            <input value={mentor} onChange={(e) => setMentor(e.target.value)} placeholder="Murabbiy ismi" className="w-full px-3 py-2 rounded-lg bg-white/10 border border-white/20 text-sm text-white placeholder:text-teal-100/40 mb-3" />
            <button onClick={saveHub} className="fx-btn px-4 py-2 rounded-lg text-sm font-semibold" style={{ background: C.accent, color: C.dark }}>Saqlash</button>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          <div className="flex items-center gap-2 mb-4"><Award size={16} className="text-teal-600" /><p className="text-xs uppercase tracking-wider text-slate-400 font-semibold">Jalb qilish darajasi</p></div>
          {roster.length === 0 ? <p className="text-sm text-slate-400 italic">Hali o'quvchi yo'q.</p> : (
            <div className="space-y-2">
              {roster.map((r) => (
                <div key={r.name} className="flex items-center justify-between px-3 py-2.5 rounded-lg bg-slate-50 border border-slate-100">
                  <div>
                    <p className="text-sm font-medium text-slate-700">{r.name}</p>
                    <p className="text-xs text-slate-400">{r.count} ta faoliyat · {r.badges.length} ta nishon</p>
                  </div>
                  <div className="flex gap-1">
                    {r.badges.slice(-3).map((b) => (
                      <span key={b} title={b} className="w-6 h-6 rounded-full flex items-center justify-center" style={{ background: "#FEF3C7" }}><Star size={12} className="text-amber-500" /></span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="rounded-2xl p-6 border border-amber-200 bg-amber-50">
        <div className="flex items-center gap-2 mb-2"><AlertTriangle size={16} className="text-amber-600" /><p className="text-sm font-semibold text-amber-800">Kam faollik ({disengaged.length})</p></div>
        {disengaged.length === 0
          ? <p className="text-sm text-amber-700/70">Hozircha faolsiz o'quvchi yo'q.</p>
          : <p className="text-sm text-amber-700/90">{disengaged.map((r) => r.name).join(", ")} — hali birorta faoliyat qilmagan. Akademik eslatma emas, balki shaxsiy tashrif yoki amaliy tajriba taklifi samaraliroq.</p>}
      </div>
    </div>
  );
}

/* ============================ Home learning ============================ */
export const ACCOMMODATION_LABELS = {
  largeText: "Katta shrift", audioHelp: "Ovozli o'qish yordami",
  extraTime: "Qo'shimcha vaqt", reducedLoad: "Kamaytirilgan yuklama",
};

export function TeacherHomeLearning({ cls, code, apply, toast }) {
  const homeStudents = Object.entries(cls.students).filter(([, d]) => d.home.active);

  async function update(student, patch) {
    try { apply(await api.updateHome(code, { student, ...patch })); }
    catch (e) { toast(e.message, "error"); }
  }

  return (
    <div className="fx-fade-up">
      <p className="text-xs uppercase tracking-wider text-slate-400 font-semibold mb-1">Uyda ta'lim</p>
      <h3 className="text-lg font-semibold text-slate-800 mb-2">Maktabga borolmaydigan o'quvchilar uchun individual reja</h3>
      <p className="text-sm text-slate-500 mb-5">Qisqa muddatli sababdan uzoq muddatli uyda ta'limgacha — har biriga moslashtirilgan yondashuv.</p>

      {homeStudents.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          <p className="text-sm text-slate-400 italic">Hozircha uyda ta'lim rejimidagi o'quvchi yo'q.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {homeStudents.map(([sname, d]) => (
            <div key={sname} className="fx-card-hover bg-white rounded-2xl border border-slate-200 p-6">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2"><Home size={15} className="text-teal-600" /><p className="text-sm font-semibold text-slate-800">{sname}</p></div>
                <Pill tone={d.home.duration === "uzoq_muddatli" ? "warn" : "pending"}>{d.home.duration === "uzoq_muddatli" ? "Uzoq muddatli" : "Vaqtinchalik"}</Pill>
              </div>

              {Object.entries(d.home.accommodations).some(([, v]) => v) && (
                <div className="flex flex-wrap gap-1.5 mb-2">
                  {Object.entries(d.home.accommodations).filter(([, v]) => v).map(([k]) => (
                    <span key={k} className="text-[11px] px-2 py-1 rounded-full bg-teal-50 text-teal-700">{ACCOMMODATION_LABELS[k] || k}</span>
                  ))}
                </div>
              )}

              {d.home.checkIns.length > 0 && (
                <div className="mt-2 space-y-1.5">
                  {d.home.checkIns.slice(-3).reverse().map((ci, i) => (
                    <div key={i} className="text-xs text-slate-500 bg-slate-50 rounded-lg px-3 py-2 border border-slate-100 flex items-center gap-2"><Coffee size={12} /> {ci}</div>
                  ))}
                </div>
              )}

              <input defaultValue={d.home.note} onBlur={(e) => update(sname, { note: e.target.value })}
                placeholder="Individual reja (masalan: haftada 3 ta qisqa mashq)" className="inp mt-3" />
            </div>
          ))}
        </div>
      )}

      <div className="rounded-2xl p-5 mt-6 border border-slate-200 bg-slate-50">
        <p className="text-xs text-slate-500 leading-relaxed">Platforma sog'liq holati yoki tashxis haqida ma'lumot saqlamaydi — faqat o'quv rejasi va moslashtirishlar.</p>
      </div>
    </div>
  );
}

/* ============================ CPD ============================ */
const CPD_COURSES = [
  { id: "c1", provider: "HarvardX (edX)", title: "Leaders of Learning", format: "Bepul kuzatish / sertifikat pullik", focus: "Ta'lim yetakchiligi" },
  { id: "c2", provider: "HarvardX (edX)", title: "CS50: Introduction to Computer Science", format: "Bepul kuzatish / sertifikat pullik", focus: "Dasturlash asoslari" },
  { id: "c3", provider: "Coursera", title: "Assessment and Feedback in Higher Education", format: "Freemium", focus: "Baholash uslublari" },
  { id: "c4", provider: "edX", title: "Adaptive Learning va Ta'lim Texnologiyalari", format: "Bepul kuzatish", focus: "Moslashuvchan o'qitish" },
];

export function TeacherProfessionalDev({ cls, code, apply, toast }) {
  const completed = cls.teacherCPD || [];
  async function toggle(id) {
    try { apply(await api.setCpd(code, id, !completed.includes(id))); }
    catch (e) { toast(e.message, "error"); }
  }
  return (
    <div className="fx-fade-up">
      <p className="text-xs uppercase tracking-wider text-slate-400 font-semibold mb-1">Malaka oshirish</p>
      <h3 className="text-lg font-semibold text-slate-800 mb-2">Xalqaro kurslar</h3>
      <p className="text-sm text-slate-500 mb-5">Kursni bepul kuzatib chiqing, so'ng shu yerda "Yakunladim" deb belgilang.</p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        {CPD_COURSES.map((c) => {
          const done = completed.includes(c.id);
          return (
            <div key={c.id} className={`fx-card-hover rounded-2xl border p-5 ${done ? "border-amber-300 bg-amber-50" : "border-slate-200 bg-white"}`}>
              <div className="flex items-center justify-between mb-1">
                <Pill tone="neutral">{c.provider}</Pill>{done && <Star size={16} className="text-amber-500" />}
              </div>
              <p className="text-sm font-semibold text-slate-800 mt-2">{c.title}</p>
              <p className="text-xs text-slate-500 mt-1">{c.focus}</p>
              <p className="text-xs text-slate-400 mt-1">{c.format}</p>
              <button onClick={() => toggle(c.id)} className={`fx-btn mt-3 px-3 py-1.5 rounded-lg text-xs font-semibold ${done ? "bg-amber-100 text-amber-700" : "text-white"}`} style={!done ? { background: C.primary } : {}}>
                {done ? "Yakunlangan ✓" : "Yakunladim deb belgilash"}
              </button>
            </div>
          );
        })}
      </div>

      <div className="rounded-2xl p-6 text-white relative overflow-hidden" style={{ background: `linear-gradient(155deg, ${C.dark2}, ${C.dark})` }}>
        <AmbientBG />
        <div className="relative flex items-center gap-3">
          <Award size={20} className="text-amber-300 shrink-0" />
          <p className="text-sm text-teal-50/90">Malaka nishonlaringiz: <b>{completed.length}</b> ta kurs yakunlangan.</p>
        </div>
      </div>
    </div>
  );
}

/* ============================ Attendance + parent messages ============================ */
export function TeacherAttendance({ cls, code, apply, toast }) {
  const today = new Date().toISOString().slice(0, 10);
  const todayRecord = cls.attendance[today] || {};
  const [replyDraft, setReplyDraft] = useState({});

  async function mark(student, status) {
    try { apply(await api.markAttendance(code, { student, day: today, status })); }
    catch (e) { toast(e.message, "error"); }
  }
  async function reply(id) {
    try { apply(await api.replyToParent(code, id, replyDraft[id] || "")); toast("Javob yuborildi"); }
    catch (e) { toast(e.message, "error"); }
  }

  return (
    <div className="fx-fade-up space-y-6">
      <div>
        <p className="text-xs uppercase tracking-wider text-slate-400 font-semibold mb-1">Davomat va ota-ona aloqasi</p>
        <h3 className="text-lg font-semibold text-slate-800">Bugungi kun — {today}</h3>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-6">
        <div className="flex items-center gap-2 mb-4"><UserCheck size={16} className="text-teal-600" /><p className="text-xs uppercase tracking-wider text-slate-400 font-semibold">Davomatni belgilash</p></div>
        {Object.keys(cls.students).length === 0 ? <p className="text-sm text-slate-400 italic">Hali o'quvchi yo'q.</p> : (
          <div className="space-y-2">
            {Object.keys(cls.students).map((sname) => {
              const status = todayRecord[sname];
              return (
                <div key={sname} className="flex items-center justify-between px-3 py-2.5 rounded-lg bg-slate-50 border border-slate-100">
                  <span className="text-sm font-medium text-slate-700">{sname}</span>
                  <div className="flex gap-1.5">
                    <button onClick={() => mark(sname, "keldi")} className={`fx-btn px-3 py-1 rounded-lg text-xs font-semibold ${status === "keldi" ? "bg-emerald-100 text-emerald-700" : "border border-slate-200 text-slate-500"}`}>Keldi</button>
                    <button onClick={() => mark(sname, "kelmadi")} className={`fx-btn px-3 py-1 rounded-lg text-xs font-semibold ${status === "kelmadi" ? "bg-rose-100 text-rose-700" : "border border-slate-200 text-slate-500"}`}>Kelmadi</button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-6">
        <div className="flex items-center gap-2 mb-4"><MessageCircle size={16} className="text-teal-600" /><p className="text-xs uppercase tracking-wider text-slate-400 font-semibold">Ota-onalardan xabarlar</p></div>
        {cls.parentMessages.length === 0 ? <p className="text-sm text-slate-400 italic">Hali xabar yo'q.</p> : (
          <div className="space-y-3">
            {cls.parentMessages.slice().reverse().map((m) => (
              <div key={m.id} className="border border-slate-100 rounded-xl p-4 bg-slate-50">
                <p className="text-xs text-slate-400 mb-1">{m.parentName} ({m.studentName} ota-onasi)</p>
                <p className="text-sm text-slate-700">{m.text}</p>
                {m.teacherReply ? (
                  <p className="text-xs text-teal-700 bg-teal-50 rounded-lg px-3 py-2 mt-2 border border-teal-100">Javobingiz: {m.teacherReply}</p>
                ) : (
                  <div className="flex gap-2 mt-2">
                    <input value={replyDraft[m.id] || ""} onChange={(e) => setReplyDraft({ ...replyDraft, [m.id]: e.target.value })} placeholder="Javob yozing…" className="flex-1 px-3 py-1.5 rounded-lg border border-slate-200 text-xs" />
                    <button onClick={() => reply(m.id)} className="fx-btn px-3 py-1.5 rounded-lg text-white text-xs font-semibold" style={{ background: C.primary }}>Yuborish</button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
