import React, { useState, useEffect } from "react";
import { Send, RefreshCw } from "lucide-react";
import { C, Pill } from "../ui.jsx";
import { api } from "../lib/api.js";

export function ParentDashboard({ cls, code, childName, apply, toast }) {
  const st = cls.students[childName] || { mastery: 0 };
  const days = Object.entries(cls.attendance).filter(([, rec]) => rec[childName]);
  const present = days.filter(([, rec]) => rec[childName] === "keldi").length;
  const subs = cls.submissions.filter((s) => s.student === childName);
  const myMessages = cls.parentMessages.filter((m) => m.studentName === childName);
  const [msg, setMsg] = useState("");

  async function send() {
    if (!msg.trim()) return;
    try { apply(await api.sendParentMessage(code, msg)); setMsg(""); toast("Xabar yuborildi"); }
    catch (e) { toast(e.message, "error"); }
  }

  return (
    <div className="max-w-4xl mx-auto p-6 fx-fade-up">
      <p className="text-xs uppercase tracking-wider text-slate-400 font-semibold mb-1">Ota-ona paneli</p>
      <h3 className="text-lg font-semibold text-slate-800 mb-5">{childName} — {cls.name}</h3>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <p className="text-xs text-slate-400 mb-1">Bilim darajasi</p>
          <p className="text-2xl font-bold" style={{ color: C.primary }}>{st.mastery}%</p>
        </div>
        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <p className="text-xs text-slate-400 mb-1">Davomat</p>
          <p className="text-2xl font-bold text-slate-800">{present}/{days.length}</p>
        </div>
        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <p className="text-xs text-slate-400 mb-1">Topshiriqlar</p>
          <p className="text-2xl font-bold text-slate-800">{subs.length}</p>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-6 mb-6">
        <p className="text-xs uppercase tracking-wider text-slate-400 font-semibold mb-3">So'nggi topshiriqlar</p>
        {subs.length === 0 ? <p className="text-sm text-slate-400 italic">Hali topshiriq yo'q.</p> : (
          <div className="space-y-2">
            {subs.slice().reverse().slice(0, 5).map((s) => (
              <div key={s.id} className="flex items-center justify-between px-3 py-2 rounded-lg bg-slate-50 border border-slate-100">
                <span className="text-sm text-slate-600">{s.questionText}</span>
                {s.status === "kutilmoqda" ? <Pill tone="pending">Tekshirilmoqda</Pill> : <Pill tone="good">{s.finalScore}/10</Pill>}
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-6">
        <p className="text-xs uppercase tracking-wider text-slate-400 font-semibold mb-3">O'qituvchiga xabar</p>
        <div className="flex gap-2">
          <input value={msg} onChange={(e) => setMsg(e.target.value)} placeholder="Savolingiz yoki izohingiz…" className="inp" />
          <button onClick={send} className="fx-btn flex items-center gap-1.5 px-4 py-2.5 rounded-lg text-white text-sm font-semibold shrink-0" style={{ background: C.primary }}>
            <Send size={14} /> Yuborish
          </button>
        </div>
        {myMessages.length > 0 && (
          <div className="space-y-2 mt-4">
            {myMessages.slice().reverse().map((m) => (
              <div key={m.id} className="border border-slate-100 rounded-xl p-3 bg-slate-50">
                <p className="text-sm text-slate-700">{m.text}</p>
                {m.teacherReply
                  ? <p className="text-xs text-teal-700 bg-teal-50 rounded-lg px-3 py-2 mt-2 border border-teal-100">O'qituvchi: {m.teacherReply}</p>
                  : <p className="text-xs text-slate-400 mt-1">Javob kutilmoqda</p>}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export function AdminDashboard({ adminName, toast }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    try { setData(await api.adminOverview()); }
    catch (e) { toast(e.message, "error"); }
    setLoading(false);
  }
  useEffect(() => { load(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, []);

  return (
    <div className="max-w-5xl mx-auto p-6 fx-fade-up">
      <p className="text-xs uppercase tracking-wider text-slate-400 font-semibold mb-1">Muassasa bo'yicha umumiy ko'rinish</p>
      <h3 className="text-lg font-semibold text-slate-800 mb-5">Xush kelibsiz, {adminName}</h3>

      {loading || !data ? (
        <div className="flex items-center gap-2 text-slate-400 text-sm"><RefreshCw size={14} className="fx-spin" /> Yuklanmoqda…</div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="bg-white rounded-2xl border border-slate-200 p-5"><p className="text-xs text-slate-400 mb-1">Jami sinflar</p><p className="text-2xl font-bold" style={{ color: C.primary }}>{data.classes.length}</p></div>
            <div className="bg-white rounded-2xl border border-slate-200 p-5"><p className="text-xs text-slate-400 mb-1">Jami o'quvchilar</p><p className="text-2xl font-bold text-slate-800">{data.totalStudents}</p></div>
            <div className="bg-white rounded-2xl border border-slate-200 p-5"><p className="text-xs text-slate-400 mb-1">O'rtacha bilim darajasi</p><p className="text-2xl font-bold text-slate-800">{data.overallAvg}%</p></div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <p className="text-xs uppercase tracking-wider text-slate-400 font-semibold">Sinflar ro'yxati</p>
              <button onClick={load} className="fx-btn flex items-center gap-1 text-xs text-teal-600 font-semibold"><RefreshCw size={12} /> Yangilash</button>
            </div>
            {data.classes.length === 0 ? <p className="text-sm text-slate-400 italic">Hozircha sinf yaratilmagan.</p> : (
              <div className="space-y-2">
                {data.classes.map((c) => (
                  <div key={c.code} className="flex items-center justify-between px-4 py-3 rounded-lg bg-slate-50 border border-slate-100">
                    <div>
                      <p className="text-sm font-semibold text-slate-800">{c.name} <span className="text-slate-400 font-normal">· {c.subject}</span></p>
                      <p className="text-xs text-slate-400">O'qituvchi: {c.teacher}</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <Pill tone="neutral">{c.studentCount} o'quvchi</Pill>
                      <Pill tone={c.avgMastery >= 60 ? "good" : c.avgMastery >= 40 ? "warn" : "neutral"}>{c.avgMastery}% o'rtacha</Pill>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </>
      )}
      <p className="text-center text-slate-300 text-[11px] mt-6">Faqat jamlangan ko'rsatkichlar — sinf kodlari va shaxsiy ma'lumotlar ko'rsatilmaydi</p>
    </div>
  );
}
