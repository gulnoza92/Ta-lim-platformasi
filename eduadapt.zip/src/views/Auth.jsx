import React, { useState } from "react";
import { GraduationCap, School, KeyRound, Plus, RefreshCw, ArrowRight, Eye, Users } from "lucide-react";
import { C, AmbientBG, KnowledgeOrbit } from "../ui.jsx";
import { api, setToken } from "../lib/api.js";

/**
 * Each role has its own credential now:
 *  - teacher: class code + class password
 *  - student: own name + own password (first time: one-time join code)
 *  - parent:  child's name + that family's parent code
 */
export default function AuthGate({ onEnter }) {
  const [mode, setMode] = useState("choose");
  const [name, setName] = useState("");
  const [className, setClassName] = useState("");
  const [subject, setSubject] = useState("Matematika");
  const [code, setCode] = useState("");
  const [password, setPassword] = useState("");
  const [joinCode, setJoinCode] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [childName, setChildName] = useState("");
  const [parentCode, setParentCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function run(fn) {
    setBusy(true); setError("");
    try { await fn(); }
    catch (e) {
      setError(e.message);
      // The server tells us when an account exists but was never activated.
      if (/faollashtirilmagan/.test(e.message)) setMode("s-activate");
    }
    finally { setBusy(false); }
  }

  const go = (r, extra = {}) => (data) => {
    setToken(data.token);
    onEnter({ role: r, name: r === "student" ? name.trim() : name, classCode: data.code, initialClass: data.class, ...extra });
  };

  const createClass = () => run(async () =>
    go("teacher")(await api.createClass({ teacherName: name, className, subject, password })));
  const teacherLogin = () => run(async () =>
    go("teacher")(await api.teacherLogin({ code, name, password })));
  const studentLogin = () => run(async () =>
    go("student")(await api.studentLogin({ code, name, password })));
  const studentActivate = () => run(async () =>
    go("student")(await api.studentActivate({ code, name, joinCode, newPassword })));
  const parentLogin = () => run(async () =>
    go("parent", { childName: childName.trim() })(await api.parentLogin({ code, name, childName, parentCode })));
  const adminLogin = () => run(async () => {
    const r = await api.adminLogin({ name, password });
    setToken(r.token);
    onEnter({ role: "admin", name });
  });

  const Back = ({ to = "choose" }) => (
    <button onClick={() => { setMode(to); setError(""); }} className="text-xs text-slate-400 mb-1">← Orqaga</button>
  );
  const Err = () => error ? <p className="text-xs text-rose-500">{error}</p> : null;
  const Submit = ({ onClick, icon: Icon, children }) => (
    <button onClick={onClick} disabled={busy}
      className="fx-btn w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-white text-sm font-semibold disabled:opacity-60"
      style={{ background: C.primary }}>
      {busy ? <RefreshCw size={15} className="fx-spin" /> : <Icon size={15} />} {children}
    </button>
  );
  const CodeInput = ({ value, onChange, placeholder, len = 5 }) => (
    <div className="relative">
      <KeyRound size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
      <input value={value} maxLength={len} onChange={(e) => onChange(e.target.value.toUpperCase().slice(0, len))}
        placeholder={placeholder} className="inp pl-9 font-mono tracking-wider" />
    </div>
  );

  return (
    <div className="min-h-screen relative flex items-center justify-center px-4 py-10 overflow-hidden"
      style={{ background: `radial-gradient(circle at 30% 20%, ${C.dark2}, ${C.dark} 60%)` }}>
      <AmbientBG />
      <div className="relative w-full max-w-md">
        <div className="flex flex-col items-center mb-8 fx-fade-up">
          <KnowledgeOrbit size={110} />
          <p className="text-white font-serif text-3xl font-bold mt-3">EduAdapt</p>
          <p className="text-teal-100/50 text-xs mt-1">Universal AI-adaptiv ta'lim platformasi</p>
        </div>

        <div className="bg-white/95 backdrop-blur rounded-2xl p-6 sm:p-7 fx-fade-up" style={{ animationDelay: "0.1s" }}>
          {mode === "choose" && (
            <div className="space-y-3">
              <p className="text-sm font-semibold text-slate-700 mb-1">Kim sifatida kirasiz?</p>
              {[
                { m: "t-login", icon: School, t: "O'qituvchi", s: "Sinfni boshqarish" },
                { m: "s-login", icon: GraduationCap, t: "O'quvchi", s: "O'z hisobingiz bilan" },
                { m: "p-login", icon: Eye, t: "Ota-ona", s: "Farzandingizni kuzatish" },
                { m: "a-login", icon: Users, t: "Admin / muassasa", s: "Umumiy ko'rsatkichlar" },
              ].map((o) => (
                <button key={o.m} onClick={() => { setMode(o.m); setError(""); }}
                  className="fx-btn w-full flex items-center gap-3 px-4 py-3.5 rounded-xl border border-slate-200 hover:border-teal-400 text-left">
                  <o.icon size={20} className="text-teal-600" />
                  <div><p className="text-sm font-semibold text-slate-800">{o.t}</p><p className="text-xs text-slate-400">{o.s}</p></div>
                </button>
              ))}
            </div>
          )}

          {mode === "t-login" && (
            <div className="space-y-3 fx-fade-up">
              <Back />
              <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ismingiz" className="inp" />
              <CodeInput value={code} onChange={setCode} placeholder="Sinf kodi" />
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Sinf paroli" className="inp" />
              <Err />
              <Submit onClick={teacherLogin} icon={ArrowRight}>Kirish</Submit>
              <button onClick={() => { setMode("t-new"); setError(""); }} className="w-full text-xs text-teal-600 font-semibold pt-1">
                Yangi sinf yaratish →
              </button>
            </div>
          )}

          {mode === "t-new" && (
            <div className="space-y-3 fx-fade-up">
              <Back to="t-login" />
              <p className="text-xs font-semibold text-slate-500">Yangi sinf</p>
              <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ismingiz" className="inp" />
              <input value={className} onChange={(e) => setClassName(e.target.value)} placeholder="Sinf nomi (masalan: 9-A matematika)" className="inp" />
              <select value={subject} onChange={(e) => setSubject(e.target.value)} className="inp bg-white">
                <option>Matematika</option><option>Geometriya</option><option>Fizika</option><option>Ona tili</option>
              </select>
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Sinf paroli (kamida 8 belgi)" className="inp" />
              <p className="text-xs text-slate-400">Bu parol faqat siz uchun. O'quvchilar o'z parollarini o'zlari yaratadi.</p>
              <Err />
              <Submit onClick={createClass} icon={Plus}>Sinf yaratish</Submit>
            </div>
          )}

          {mode === "s-login" && (
            <div className="space-y-3 fx-fade-up">
              <Back />
              <CodeInput value={code} onChange={setCode} placeholder="Sinf kodi" />
              <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ismingiz (ro'yxatdagidek)" className="inp" />
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Parolingiz" className="inp" />
              <Err />
              <Submit onClick={studentLogin} icon={ArrowRight}>Kirish</Submit>
              <button onClick={() => { setMode("s-activate"); setError(""); }} className="w-full text-xs text-teal-600 font-semibold pt-1">
                Birinchi marta kiryapman →
              </button>
            </div>
          )}

          {mode === "s-activate" && (
            <div className="space-y-3 fx-fade-up">
              <Back to="s-login" />
              <p className="text-xs font-semibold text-slate-500">Hisobni faollashtirish</p>
              <CodeInput value={code} onChange={setCode} placeholder="Sinf kodi" />
              <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ismingiz (ro'yxatdagidek)" className="inp" />
              <CodeInput value={joinCode} onChange={setJoinCode} placeholder="Bir martalik kod" len={6} />
              <input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} placeholder="O'zingiz uchun parol (kamida 6 belgi)" className="inp" />
              <p className="text-xs text-slate-400">Bir martalik kodni o'qituvchingiz beradi. Parolni hech kimga aytmang.</p>
              <Err />
              <Submit onClick={studentActivate} icon={ArrowRight}>Faollashtirish</Submit>
            </div>
          )}

          {mode === "p-login" && (
            <div className="space-y-3 fx-fade-up">
              <Back />
              <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ismingiz (ota-ona)" className="inp" />
              <CodeInput value={code} onChange={setCode} placeholder="Sinf kodi" />
              <input value={childName} onChange={(e) => setChildName(e.target.value)} placeholder="Farzandingizning ismi" className="inp" />
              <CodeInput value={parentCode} onChange={setParentCode} placeholder="Ota-ona kodi" len={6} />
              <p className="text-xs text-slate-400">Ota-ona kodi har bir oila uchun alohida — o'qituvchidan oling.</p>
              <Err />
              <Submit onClick={parentLogin} icon={Eye}>Kuzatishni boshlash</Submit>
            </div>
          )}

          {mode === "a-login" && (
            <div className="space-y-3 fx-fade-up">
              <Back />
              <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ismingiz (direktor/mutasaddi)" className="inp" />
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Admin paroli" className="inp" />
              <Err />
              <Submit onClick={adminLogin} icon={Users}>Umumiy ko'rinishga kirish</Submit>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
