import React, { useState } from "react";
import { UserPlus, Trash2, RotateCcw, Download, Plus, Sparkles, Copy, Check } from "lucide-react";
import { C, Pill } from "../ui.jsx";
import { api, parseJsonLoose } from "../lib/api.js";

/** Shows an access code with a one-tap copy button. */
function CodeChip({ value }) {
  const [copied, setCopied] = useState(false);
  if (!value) return <span className="text-xs text-slate-300">—</span>;
  return (
    <button
      onClick={async () => {
        try { await navigator.clipboard.writeText(value); setCopied(true); setTimeout(() => setCopied(false), 1500); }
        catch { /* clipboard blocked — the code is still visible */ }
      }}
      className="fx-btn inline-flex items-center gap-1 px-2 py-1 rounded-md bg-slate-100 font-mono text-xs text-slate-700">
      {value} {copied ? <Check size={11} className="text-emerald-600" /> : <Copy size={11} className="text-slate-400" />}
    </button>
  );
}

/* ============================ Roster ============================ */
export function TeacherRoster({ cls, code, apply, toast }) {
  const [newName, setNewName] = useState("");
  const [busy, setBusy] = useState(false);
  const students = Object.entries(cls.students);

  async function addStudent() {
    if (!newName.trim()) return;
    setBusy(true);
    try {
      const r = await api.addStudent(code, newName.trim());
      apply(r.class);
      setNewName("");
      toast(`${newName.trim()} qo'shildi — kod: ${r.joinCode}`);
    } catch (e) { toast(e.message, "error"); }
    setBusy(false);
  }

  async function reset(name) {
    try {
      const r = await api.resetStudent(code, name);
      apply(r.class);
      toast(`${name} uchun yangi kod: ${r.joinCode}`);
    } catch (e) { toast(e.message, "error"); }
  }

  async function remove(name) {
    // Deleting cascades to grades and attendance, so make it deliberate.
    if (!window.confirm(`${name} ro'yxatdan o'chirilsinmi? Uning barcha baholari va davomati ham o'chadi.`)) return;
    try { apply(await api.removeStudent(code, name)); toast(`${name} o'chirildi`); }
    catch (e) { toast(e.message, "error"); }
  }

  return (
    <div className="fx-fade-up">
      <p className="text-xs uppercase tracking-wider text-slate-400 font-semibold mb-1">Sinf ro'yxati</p>
      <h3 className="text-lg font-semibold text-slate-800 mb-2">Har bir o'quvchi — o'z hisobi bilan</h3>
      <p className="text-sm text-slate-500 mb-5">
        O'quvchi qo'shsangiz, tizim bir martalik kod beradi. O'quvchi shu kod bilan birinchi marta kirib,
        o'zi uchun parol yaratadi. Shundan keyin faqat o'zi kira oladi.
      </p>

      <div className="bg-white rounded-2xl border border-slate-200 p-5 mb-5">
        <div className="flex flex-col sm:flex-row gap-2">
          <input value={newName} onChange={(e) => setNewName(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && addStudent()}
            placeholder="O'quvchi ismi va familiyasi" className="inp" />
          <button onClick={addStudent} disabled={busy}
            className="fx-btn flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-white text-sm font-semibold shrink-0 disabled:opacity-60"
            style={{ background: C.primary }}>
            <UserPlus size={16} /> Qo'shish
          </button>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 mb-4">
        {[["roster", "Ro'yxat va kodlar"], ["grades", "Baholar"], ["attendance", "Davomat"]].map(([kind, label]) => (
          <button key={kind}
            onClick={() => api.downloadCsv(code, kind).catch((e) => toast(e.message, "error"))}
            className="fx-btn flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 text-xs font-semibold text-slate-600">
            <Download size={13} /> {label}
          </button>
        ))}
      </div>

      {students.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          <p className="text-sm text-slate-400 italic">Ro'yxat bo'sh. Yuqoridan o'quvchi qo'shing.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {students.map(([name, s]) => (
            <div key={name} className="bg-white rounded-2xl border border-slate-200 p-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="text-sm font-semibold text-slate-800">{name}</p>
                  <p className="text-xs text-slate-400">Daraja {s.mastery}% · {s.engagement.count} faoliyat</p>
                </div>
                <div className="flex items-center gap-2">
                  {s.activated
                    ? <Pill tone="good">Faollashtirilgan</Pill>
                    : <Pill tone="warn">Kirish kutilmoqda</Pill>}
                  <button onClick={() => reset(name)} title="Parolni tiklash"
                    className="fx-btn w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center text-slate-400 hover:text-teal-600">
                    <RotateCcw size={14} />
                  </button>
                  <button onClick={() => remove(name)} title="O'chirish"
                    className="fx-btn w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center text-slate-400 hover:text-rose-600">
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
              <div className="flex flex-wrap gap-4 mt-3 pt-3 border-t border-slate-100">
                <div><p className="text-[11px] text-slate-400 mb-1">Bir martalik kod</p><CodeChip value={s.joinCode} /></div>
                <div><p className="text-[11px] text-slate-400 mb-1">Ota-ona kodi</p><CodeChip value={s.parentCode} /></div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ============================ Quiz bank ============================ */
const LEVELS = [["oson", "Oson"], ["orta", "O'rta"], ["qiyin", "Qiyin"]];

export function TeacherQuizBank({ cls, code, apply, toast }) {
  const [level, setLevel] = useState("orta");
  const [question, setQuestion] = useState("");
  const [options, setOptions] = useState(["", "", "", ""]);
  const [answer, setAnswer] = useState("");
  const [loading, setLoading] = useState(false);

  function reset() { setQuestion(""); setOptions(["", "", "", ""]); setAnswer(""); }

  async function add() {
    try {
      apply(await api.addQuizQuestion(code, { level, question, options, answer }));
      reset();
      toast("Savol qo'shildi");
    } catch (e) { toast(e.message, "error"); }
  }

  async function generate() {
    setLoading(true);
    try {
      const raw = await api.ask(
        `Sen o'zbek tilida ${cls.subject} o'qituvchisisan. "${level}" darajada bitta test savoli yoz: 4 ta variant, bittasi to'g'ri. Faqat JSON: {"question":"...","options":["...","...","...","..."],"answer":"..."}`
      );
      const p = parseJsonLoose(raw);
      if (!p?.question || !Array.isArray(p.options)) throw new Error("AI javobini o'qib bo'lmadi");
      setQuestion(p.question);
      setOptions([...p.options, "", "", "", ""].slice(0, 4));
      setAnswer(p.answer || "");
      toast("AI savol tayyorladi — tekshirib, saqlang");
    } catch (e) { toast(e.message, "error"); }
    setLoading(false);
  }

  async function remove(id) {
    try { apply(await api.removeQuizQuestion(code, id)); toast("Savol o'chirildi"); }
    catch (e) { toast(e.message, "error"); }
  }

  const byLevel = (lv) => cls.quizQuestions.filter((q) => q.level === lv);

  return (
    <div className="fx-fade-up">
      <p className="text-xs uppercase tracking-wider text-slate-400 font-semibold mb-1">Test savollari</p>
      <h3 className="text-lg font-semibold text-slate-800 mb-2">Adaptiv test bazasi — {cls.quizQuestions.length} ta savol</h3>
      <p className="text-sm text-slate-500 mb-5">
        O'quvchi to'g'ri javob bersa, tizim keyingi savolni qiyinroq darajadan beradi. Har bir darajada
        kamida 3–4 ta savol bo'lgani ma'qul.
      </p>

      <div className="bg-white rounded-2xl border border-slate-200 p-5 mb-6">
        <div className="flex gap-2 mb-3">
          {LEVELS.map(([v, label]) => (
            <button key={v} onClick={() => setLevel(v)}
              className={`fx-btn flex-1 px-3 py-2 rounded-lg text-sm font-medium border ${level === v ? "border-teal-400 bg-teal-50 text-teal-700" : "border-slate-200 text-slate-500"}`}>
              {label}
            </button>
          ))}
        </div>

        <input value={question} onChange={(e) => setQuestion(e.target.value)} placeholder="Savol matni" className="inp mb-2" />
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-2">
          {options.map((o, i) => (
            <input key={i} value={o} placeholder={`${i + 1}-variant`} className="inp"
              onChange={(e) => setOptions(options.map((x, j) => (j === i ? e.target.value : x)))} />
          ))}
        </div>
        <select value={answer} onChange={(e) => setAnswer(e.target.value)} className="inp bg-white mb-3">
          <option value="">To'g'ri javobni tanlang</option>
          {options.filter(Boolean).map((o) => <option key={o} value={o}>{o}</option>)}
        </select>

        <div className="flex flex-col sm:flex-row gap-2">
          <button onClick={add} className="fx-btn flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-white text-sm font-semibold" style={{ background: C.primary }}>
            <Plus size={16} /> Saqlash
          </button>
          <button onClick={generate} disabled={loading}
            className="fx-btn relative overflow-hidden flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg border border-slate-200 text-sm font-semibold text-slate-600 disabled:opacity-70">
            {loading && <span className="absolute inset-0 fx-shimmer" />}
            <Sparkles size={16} /> {loading ? "AI yozmoqda…" : "AI taklif qilsin"}
          </button>
        </div>
      </div>

      {LEVELS.map(([lv, label]) => (
        <div key={lv} className="mb-5">
          <div className="flex items-center gap-2 mb-2">
            <p className="text-xs uppercase tracking-wider text-slate-400 font-semibold">{label}</p>
            <Pill tone={byLevel(lv).length < 3 ? "warn" : "good"}>{byLevel(lv).length} ta</Pill>
          </div>
          {byLevel(lv).length === 0 ? <p className="text-sm text-slate-400 italic">Savol yo'q.</p> : (
            <div className="space-y-2">
              {byLevel(lv).map((q) => (
                <div key={q.id} className="bg-white rounded-xl border border-slate-200 p-4 flex items-start justify-between gap-3">
                  <div>
                    <p className="text-sm text-slate-800">{q.question}</p>
                    <p className="text-xs text-slate-400 mt-1">{q.options.join(" · ")}</p>
                    <p className="text-[11px] text-slate-300 mt-1">{q.createdBy}</p>
                  </div>
                  <button onClick={() => remove(q.id)}
                    className="fx-btn w-8 h-8 shrink-0 rounded-lg border border-slate-200 flex items-center justify-center text-slate-400 hover:text-rose-600">
                    <Trash2 size={14} />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
