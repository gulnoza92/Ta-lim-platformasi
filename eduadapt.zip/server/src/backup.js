import fs from "node:fs";
import path from "node:path";
import { db } from "./db.js";

const DB_PATH = process.env.DB_PATH || "./data/eduadapt.db";
const BACKUP_DIR = process.env.BACKUP_DIR || path.join(path.dirname(DB_PATH), "backups");
const KEEP = Number(process.env.BACKUP_KEEP || 14);

/**
 * better-sqlite3's backup() is safe on a live database — it copies pages
 * under a read lock rather than reading the file from underneath WAL.
 */
export async function runBackup() {
  fs.mkdirSync(BACKUP_DIR, { recursive: true });
  const stamp = new Date().toISOString().slice(0, 10);
  const target = path.join(BACKUP_DIR, `eduadapt-${stamp}.db`);

  try {
    await db.backup(target);
    rotate();
    console.log(`Zaxira nusxa: ${target}`);
    return target;
  } catch (e) {
    console.error("Zaxira nusxa muvaffaqiyatsiz:", e.message);
    return null;
  }
}

/** Keeps only the newest KEEP files so the disk can't fill up silently. */
function rotate() {
  const files = fs.readdirSync(BACKUP_DIR)
    .filter((f) => f.startsWith("eduadapt-") && f.endsWith(".db"))
    .sort()
    .reverse();
  for (const stale of files.slice(KEEP)) {
    fs.unlinkSync(path.join(BACKUP_DIR, stale));
  }
}

/** One backup at boot, then one every 24 hours. */
export function scheduleBackups() {
  runBackup();
  const timer = setInterval(runBackup, 24 * 60 * 60 * 1000);
  timer.unref();
}
