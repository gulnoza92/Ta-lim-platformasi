import "dotenv/config";
import express from "express";
import cors from "cors";
import rateLimit from "express-rate-limit";

import { authRouter } from "./routes/auth.routes.js";
import { classRouter, adminRouter } from "./routes/class.routes.js";
import { aiRouter } from "./routes/ai.routes.js";
import { scheduleBackups } from "./backup.js";

const app = express();

app.set("trust proxy", 1);
app.use(express.json({ limit: "64kb" }));
app.use(cors({ origin: (process.env.CORS_ORIGIN || "http://localhost:5173").split(","), credentials: false }));
app.use(rateLimit({ windowMs: 60 * 1000, limit: 300 }));

app.get("/api/health", (_req, res) => res.json({ ok: true }));
app.use("/api/auth", authRouter);
app.use("/api/classes", classRouter);
app.use("/api/admin", adminRouter);
app.use("/api/ai", aiRouter);

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "Serverda kutilmagan xatolik" });
});

const port = Number(process.env.PORT || 8787);
app.listen(port, () => {
  console.log(`EduAdapt server: http://localhost:${port}`);
  scheduleBackups();
});
