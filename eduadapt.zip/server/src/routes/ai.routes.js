import { Router } from "express";
import rateLimit from "express-rate-limit";
import { requireAuth, requireRole } from "../auth.js";

export const aiRouter = Router();

/* The key lives here only. The browser never sees it. */
const API_KEY = process.env.ANTHROPIC_API_KEY;
const MODEL = process.env.AI_MODEL || "claude-sonnet-4-6";

/* Per-user cap: without it, one runaway loop in the UI burns the whole budget. */
const aiLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 15,
  keyGenerator: (req) => `${req.user.role}:${req.user.classId}:${req.user.name}`,
});

aiRouter.use(requireAuth, requireRole("teacher", "student"), aiLimiter);

aiRouter.post("/", async (req, res) => {
  if (!API_KEY) return res.status(503).json({ error: "AI sozlanmagan (ANTHROPIC_API_KEY yo'q)" });

  const prompt = (req.body?.prompt || "").toString().slice(0, 4000);
  if (!prompt.trim()) return res.status(400).json({ error: "prompt bo'sh" });

  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 1000,
        messages: [{ role: "user", content: prompt }],
      }),
    });

    if (!r.ok) {
      const detail = await r.text();
      console.error("Anthropic error:", r.status, detail);
      return res.status(502).json({ error: "AI xizmatida xatolik" });
    }

    const data = await r.json();
    const text = (data.content || []).map((b) => b.text || "").join("\n");
    res.json({ text });
  } catch (e) {
    console.error(e);
    res.status(502).json({ error: "AI xizmatiga ulanib bo'lmadi" });
  }
});
