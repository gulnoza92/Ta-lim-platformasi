import { Router } from "express";
import { db, classView, findStudent } from "../db.js";
import { requireAuth, requireRole, requireClassMatch, hashPassword } from "../auth.js";
import { randomCode } from "./auth.routes.js";

export const classRouter = Router({ mergeParams: true });

classRouter.use(requireAuth);
classRouter.use("/:code", requireClassMatch);

const BADGE_MILESTONES = [
  { at: 1, name: "Birinchi qadam" },
  { at: 5, name: "Faol ishtirokchi" },
  { at: 15, name: "Barqaror o'quvchi" },
  { at: 30, name: "Ilm yulduzi" },
];

/** Increments engagement for one student and awards any milestone reached. */
function bumpEngagement(studentId) {
  db.prepare("UPDATE students SET engagement = engagement + 1 WHERE id = ?").run(studentId);
  const { engagement } = db.prepare("SELECT engagement FROM students WHERE id = ?").get(studentId);
  const milestone = BADGE_MILESTONES.find((m) => m.at === engagement);
  if (milestone) {
    db.prepare("INSERT OR IGNORE INTO badges (student_id, name) VALUES (?, ?)").run(studentId, milestone.name);
  }
}

/**
 * Resolves the student a request is allowed to act on. A student/parent token
 * is pinned to its own student row, so passing someone else's name is ignored.
 */
function ownStudent(req, res) {
  const name = req.user.role === "teacher" ? req.body.student : req.user.studentName;
  const student = name ? findStudent(req.cls.id, name) : null;
  if (!student) { res.status(404).json({ error: "O'quvchi topilmadi" }); return null; }
  return student;
}

/** Only the teacher may see join/parent codes. */
const view = (req) => classView(req.cls.id, { includeCodes: req.user.role === "teacher" });

/* ---------- Read ---------- */
classRouter.get("/:code", (req, res) =>
  res.json(classView(req.cls.id, { includeCodes: req.user.role === "teacher" })));

/* ---------- Lessons (teacher only) ---------- */
classRouter.post("/:code/lessons", requireRole("teacher"), (req, res) => {
  const { title, body, guidingQuestion = "", createdBy } = req.body || {};
  if (!title?.trim() || !body?.trim()) return res.status(400).json({ error: "Mavzu va matn kerak" });
  db.prepare(
    "INSERT INTO lessons (class_id, title, body, guiding_question, created_by) VALUES (?, ?, ?, ?, ?)"
  ).run(req.cls.id, title.trim(), body.trim(), guidingQuestion, createdBy || req.user.name);
  res.status(201).json(view(req));
});

/* ---------- Submissions ---------- */
classRouter.post("/:code/submissions", requireRole("student"), (req, res) => {
  const student = ownStudent(req, res);
  if (!student) return;
  const { questionId, answer, aiScore, aiNote = "", guidingQuestion = "" } = req.body || {};
  if (!answer?.trim()) return res.status(400).json({ error: "Javob bo'sh bo'lmasin" });

  const q = db.prepare("SELECT * FROM open_questions WHERE id = ? AND class_id = ?").get(questionId, req.cls.id);
  if (!q) return res.status(400).json({ error: "Savol topilmadi" });

  const score = Number.isFinite(Number(aiScore)) ? Math.max(0, Math.min(10, Number(aiScore))) : null;

  db.transaction(() => {
    db.prepare(
      `INSERT INTO submissions (class_id, student_id, question_id, question_text, answer, ai_score, ai_note, guiding_question)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(req.cls.id, student.id, q.id, q.text, answer.trim(), score, aiNote, guidingQuestion);
    bumpEngagement(student.id);
  })();

  res.status(201).json(view(req));
});

/** Teacher approves or edits the AI's suggested grade. */
classRouter.patch("/:code/submissions/:id", requireRole("teacher"), (req, res) => {
  const sub = db.prepare("SELECT * FROM submissions WHERE id = ? AND class_id = ?").get(req.params.id, req.cls.id);
  if (!sub) return res.status(404).json({ error: "Topshiriq topilmadi" });

  const { action, score, note } = req.body || {};
  if (action === "approve") {
    db.prepare("UPDATE submissions SET status = 'tasdiqlangan', final_score = ai_score WHERE id = ?").run(sub.id);
  } else if (action === "edit") {
    const raw = Number(score);
    if (!Number.isFinite(raw)) return res.status(400).json({ error: "Baho 0-10 oralig'ida bo'lsin" });
    const finalScore = Math.max(0, Math.min(10, Math.round(raw)));
    db.prepare("UPDATE submissions SET status = 'tahrirlangan', final_score = ?, ai_note = ? WHERE id = ?")
      .run(finalScore, note ?? sub.ai_note, sub.id);
  } else {
    return res.status(400).json({ error: "action: approve yoki edit" });
  }
  res.json(view(req));
});

/* ---------- Hub (teacher only) ---------- */
classRouter.patch("/:code/hub", requireRole("teacher"), (req, res) => {
  const { mentor = "", mobileLabNext = "" } = req.body || {};
  db.prepare("UPDATE classes SET hub_mentor = ?, hub_next_lab = ? WHERE id = ?")
    .run(mentor, mobileLabNext, req.cls.id);
  res.json(view(req));
});

/* ---------- Home learning ---------- */
classRouter.patch("/:code/home", requireRole("student", "teacher"), (req, res) => {
  const student = ownStudent(req, res);
  if (!student) return;
  const cur = db.prepare("SELECT * FROM home_plans WHERE student_id = ?").get(student.id)
    || { active: 0, note: "", duration: "vaqtinchalik", accommodations: "{}" };

  // A student sets their own mode and accommodations; only the teacher writes the plan note.
  // Every field falls back to the stored value, so a partial request can't wipe the rest.
  const isTeacher = req.user.role === "teacher";
  const active = isTeacher ? cur.active : (req.body.active ?? !!cur.active) ? 1 : 0;
  const duration = req.body.duration ?? cur.duration;
  const accommodations = isTeacher
    ? cur.accommodations
    : JSON.stringify(req.body.accommodations ?? JSON.parse(cur.accommodations || "{}"));
  const note = isTeacher ? (req.body.note ?? cur.note) : cur.note;

  db.prepare(
    `INSERT INTO home_plans (student_id, active, note, duration, accommodations) VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(student_id) DO UPDATE SET active = excluded.active, note = excluded.note,
       duration = excluded.duration, accommodations = excluded.accommodations`
  ).run(student.id, active, note, duration, accommodations);

  res.json(view(req));
});

classRouter.post("/:code/home/check-ins", requireRole("student"), (req, res) => {
  const student = ownStudent(req, res);
  if (!student) return;
  const text = (req.body?.text || "").trim();
  if (!text) return res.status(400).json({ error: "Xabar bo'sh bo'lmasin" });
  db.prepare("INSERT INTO home_checkins (student_id, text) VALUES (?, ?)").run(student.id, text);
  res.status(201).json(view(req));
});

/* ---------- Attendance (teacher only) ---------- */
classRouter.put("/:code/attendance", requireRole("teacher"), (req, res) => {
  const { student: name, day, status } = req.body || {};
  if (!["keldi", "kelmadi"].includes(status)) return res.status(400).json({ error: "status: keldi | kelmadi" });
  if (!/^\d{4}-\d{2}-\d{2}$/.test(day || "")) return res.status(400).json({ error: "Sana YYYY-MM-DD ko'rinishida" });
  const student = findStudent(req.cls.id, name);
  if (!student) return res.status(404).json({ error: "O'quvchi topilmadi" });

  db.prepare(
    `INSERT INTO attendance (class_id, student_id, day, status) VALUES (?, ?, ?, ?)
     ON CONFLICT(class_id, student_id, day) DO UPDATE SET status = excluded.status`
  ).run(req.cls.id, student.id, day, status);
  res.json(view(req));
});

/* ---------- Parent messages ---------- */
classRouter.post("/:code/messages", requireRole("parent"), (req, res) => {
  const student = findStudent(req.cls.id, req.user.studentName);
  if (!student) return res.status(404).json({ error: "O'quvchi topilmadi" });
  const text = (req.body?.text || "").trim();
  if (!text) return res.status(400).json({ error: "Xabar bo'sh bo'lmasin" });
  db.prepare("INSERT INTO parent_messages (class_id, student_id, parent_name, text) VALUES (?, ?, ?, ?)")
    .run(req.cls.id, student.id, req.user.name, text);
  res.status(201).json(view(req));
});

classRouter.patch("/:code/messages/:id", requireRole("teacher"), (req, res) => {
  const reply = (req.body?.reply || "").trim();
  if (!reply) return res.status(400).json({ error: "Javob bo'sh bo'lmasin" });
  const info = db.prepare("UPDATE parent_messages SET teacher_reply = ? WHERE id = ? AND class_id = ?")
    .run(reply, req.params.id, req.cls.id);
  if (!info.changes) return res.status(404).json({ error: "Xabar topilmadi" });
  res.json(view(req));
});

/* ---------- Teacher CPD ---------- */
classRouter.put("/:code/cpd", requireRole("teacher"), (req, res) => {
  const { courseId, completed } = req.body || {};
  if (!courseId) return res.status(400).json({ error: "courseId kerak" });
  if (completed) {
    db.prepare("INSERT OR IGNORE INTO teacher_cpd (class_id, course_id) VALUES (?, ?)").run(req.cls.id, courseId);
  } else {
    db.prepare("DELETE FROM teacher_cpd WHERE class_id = ? AND course_id = ?").run(req.cls.id, courseId);
  }
  res.json(view(req));
});


/* ---------- Roster management (teacher only) ---------- */

/** Adds a student and issues the one-time code they activate with. */
classRouter.post("/:code/students", requireRole("teacher"), (req, res) => {
  const name = (req.body?.name || "").trim();
  if (!name) return res.status(400).json({ error: "O'quvchi ismini kiriting" });
  if (findStudent(req.cls.id, name)) return res.status(409).json({ error: "Bu ism ro'yxatda bor" });

  const joinCode = randomCode(6);
  const parentCode = randomCode(6);
  db.transaction(() => {
    const { lastInsertRowid: sid } = db.prepare(
      "INSERT INTO students (class_id, name, join_code, parent_code) VALUES (?, ?, ?, ?)"
    ).run(req.cls.id, name, joinCode, parentCode);
    db.prepare("INSERT INTO home_plans (student_id) VALUES (?)").run(sid);
  })();

  res.status(201).json({ joinCode, parentCode, class: view(req) });
});

/** Re-issues a one-time code when a student forgets their password. */
classRouter.post("/:code/students/:name/reset", requireRole("teacher"), (req, res) => {
  const student = findStudent(req.cls.id, req.params.name);
  if (!student) return res.status(404).json({ error: "O'quvchi topilmadi" });
  const joinCode = randomCode(6);
  db.prepare("UPDATE students SET join_code = ?, password_hash = NULL WHERE id = ?").run(joinCode, student.id);
  res.json({ joinCode, class: view(req) });
});

/** Removes a student. Cascades to grades, attendance and messages. */
classRouter.delete("/:code/students/:name", requireRole("teacher"), (req, res) => {
  const student = findStudent(req.cls.id, req.params.name);
  if (!student) return res.status(404).json({ error: "O'quvchi topilmadi" });
  db.prepare("DELETE FROM students WHERE id = ?").run(student.id);
  res.json(view(req));
});

/* ---------- Quiz bank ---------- */

classRouter.post("/:code/quiz-questions", requireRole("teacher"), (req, res) => {
  const { level, question, options, answer } = req.body || {};
  if (!["oson", "orta", "qiyin"].includes(level)) return res.status(400).json({ error: "Daraja: oson | orta | qiyin" });
  if (!question?.trim()) return res.status(400).json({ error: "Savol matnini kiriting" });
  const opts = (options || []).map((o) => String(o).trim()).filter(Boolean);
  if (opts.length < 2) return res.status(400).json({ error: "Kamida 2 ta variant kerak" });
  if (!opts.includes(String(answer || "").trim())) return res.status(400).json({ error: "To'g'ri javob variantlar orasida bo'lsin" });

  db.prepare(
    "INSERT INTO quiz_questions (class_id, level, question, options, answer, created_by) VALUES (?, ?, ?, ?, ?, ?)"
  ).run(req.cls.id, level, question.trim(), JSON.stringify(opts), String(answer).trim(), req.user.name);
  res.status(201).json(view(req));
});

classRouter.delete("/:code/quiz-questions/:id", requireRole("teacher"), (req, res) => {
  const info = db.prepare("DELETE FROM quiz_questions WHERE id = ? AND class_id = ?").run(req.params.id, req.cls.id);
  if (!info.changes) return res.status(404).json({ error: "Savol topilmadi" });
  res.json(view(req));
});

/** Serves the next question WITHOUT the answer, so it can't be read
 *  out of the network tab. */
classRouter.get("/:code/quiz/next", requireRole("student"), (req, res) => {
  const level = ["oson", "orta", "qiyin"].includes(req.query.level) ? req.query.level : "orta";
  let q = db.prepare(
    "SELECT id, level, question, options FROM quiz_questions WHERE class_id = ? AND level = ? ORDER BY RANDOM() LIMIT 1"
  ).get(req.cls.id, level);
  if (!q) {
    q = db.prepare(
      "SELECT id, level, question, options FROM quiz_questions WHERE class_id = ? ORDER BY RANDOM() LIMIT 1"
    ).get(req.cls.id);
  }
  if (!q) return res.status(404).json({ error: "Bu sinfda hali test savoli yo'q" });
  res.json({ ...q, options: JSON.parse(q.options) });
});

/** The server marks the answer and updates mastery. */
classRouter.post("/:code/quiz/answer", requireRole("student"), (req, res) => {
  const student = ownStudent(req, res);
  if (!student) return;
  const q = db.prepare("SELECT * FROM quiz_questions WHERE id = ? AND class_id = ?").get(req.body?.questionId, req.cls.id);
  if (!q) return res.status(404).json({ error: "Savol topilmadi" });

  const correct = String(req.body?.choice || "").trim() === q.answer;
  const mastery = Math.max(5, Math.min(98, student.mastery + (correct ? 8 : -10)));

  db.transaction(() => {
    db.prepare("UPDATE students SET mastery = ? WHERE id = ?").run(mastery, student.id);
    db.prepare("INSERT INTO mastery_history (student_id, mastery) VALUES (?, ?)").run(student.id, mastery);
    bumpEngagement(student.id);
  })();

  res.json({ correct, correctAnswer: q.answer, mastery });
});

/* ---------- CSV export (teacher only) ---------- */

function csv(rows) {
  const esc = (v) => `"${String(v ?? "").replace(/"/g, '""')}"`;
  // The BOM makes Excel open UTF-8 correctly instead of mangling o' and g'.
  return "\uFEFF" + rows.map((r) => r.map(esc).join(",")).join("\r\n");
}
function sendCsv(res, filename, rows) {
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
  res.send(csv(rows));
}

classRouter.get("/:code/export/grades.csv", requireRole("teacher"), (req, res) => {
  const rows = [["O'quvchi", "Savol", "Javob", "AI taklifi", "Yakuniy baho", "Holat", "Sana"]];
  for (const s of db.prepare(
    `SELECT st.name, sub.question_text, sub.answer, sub.ai_score, sub.final_score, sub.status, sub.created_at
     FROM submissions sub JOIN students st ON st.id = sub.student_id
     WHERE sub.class_id = ? ORDER BY st.name, sub.id`
  ).all(req.cls.id)) {
    rows.push([s.name, s.question_text, s.answer, s.ai_score, s.final_score, s.status, s.created_at]);
  }
  sendCsv(res, `baholar-${req.cls.code}.csv`, rows);
});

classRouter.get("/:code/export/attendance.csv", requireRole("teacher"), (req, res) => {
  const days = db.prepare("SELECT DISTINCT day FROM attendance WHERE class_id = ? ORDER BY day").all(req.cls.id).map((d) => d.day);
  const students = db.prepare("SELECT id, name FROM students WHERE class_id = ? ORDER BY name").all(req.cls.id);
  const marks = db.prepare("SELECT student_id, day, status FROM attendance WHERE class_id = ?").all(req.cls.id);

  const rows = [["O'quvchi", ...days, "Kelgan kunlar"]];
  for (const st of students) {
    const cells = days.map((d) => marks.find((m) => m.student_id === st.id && m.day === d)?.status || "");
    rows.push([st.name, ...cells, cells.filter((c) => c === "keldi").length]);
  }
  sendCsv(res, `davomat-${req.cls.code}.csv`, rows);
});

classRouter.get("/:code/export/roster.csv", requireRole("teacher"), (req, res) => {
  const rows = [["O'quvchi", "Daraja %", "Faoliyat", "Holat", "Bir martalik kod", "Ota-ona kodi"]];
  for (const s of db.prepare("SELECT * FROM students WHERE class_id = ? ORDER BY name").all(req.cls.id)) {
    rows.push([s.name, s.mastery, s.engagement,
      s.password_hash ? "faollashtirilgan" : "kutilmoqda",
      s.join_code || "-", s.parent_code || "-"]);
  }
  sendCsv(res, `royxat-${req.cls.code}.csv`, rows);
});

/* ---------- Admin overview (aggregate only, no class internals) ---------- */
export const adminRouter = Router();
adminRouter.use(requireAuth, requireRole("admin"));
adminRouter.get("/overview", (_req, res) => {
  const rows = db.prepare(
    `SELECT c.code, c.name, c.subject, c.teacher_name AS teacher,
            COUNT(s.id) AS studentCount,
            COALESCE(CAST(ROUND(AVG(s.mastery)) AS INTEGER), 0) AS avgMastery
     FROM classes c LEFT JOIN students s ON s.class_id = c.id
     GROUP BY c.id ORDER BY c.name`
  ).all();
  const totalStudents = rows.reduce((a, r) => a + r.studentCount, 0);
  const overallAvg = totalStudents
    ? Math.round(rows.reduce((a, r) => a + r.avgMastery * r.studentCount, 0) / totalStudents)
    : 0;
  res.json({ classes: rows, totalStudents, overallAvg });
});
