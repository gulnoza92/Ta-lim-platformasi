import { Router } from "express";
import rateLimit from "express-rate-limit";
import { db, findClassByCode, findStudent, classView } from "../db.js";
import { hashPassword, checkPassword, signToken } from "../auth.js";
import { DEFAULT_LESSONS, DEFAULT_QUESTIONS, QUIZ_BANK } from "../seed.js";

export const authRouter = Router();

const loginLimiter = rateLimit({ windowMs: 10 * 60 * 1000, limit: 20 });

/* Ambiguous characters (0/O, 1/I) are excluded — these codes get read off
   paper and typed by children. */
const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
const randomCode = (n) =>
  Array.from({ length: n }, () => ALPHABET[Math.floor(Math.random() * ALPHABET.length)]).join("");

function uniqueClassCode() {
  for (let i = 0; i < 50; i++) {
    const code = randomCode(5);
    if (!findClassByCode(code)) return code;
  }
  throw new Error("Bo'sh sinf kodi topilmadi");
}

export function seedClass(classId, subject) {
  const insLesson = db.prepare(
    "INSERT INTO lessons (class_id, title, body, guiding_question, created_by) VALUES (?, ?, ?, ?, 'Namuna materiali')"
  );
  for (const l of DEFAULT_LESSONS[subject]) insLesson.run(classId, l.title, l.body, l.guidingQuestion);

  const insQ = db.prepare("INSERT INTO open_questions (class_id, text) VALUES (?, ?)");
  for (const q of DEFAULT_QUESTIONS) insQ.run(classId, q);

  const insQuiz = db.prepare(
    "INSERT INTO quiz_questions (class_id, level, question, options, answer, created_by) VALUES (?, ?, ?, ?, ?, 'Namuna')"
  );
  for (const q of QUIZ_BANK[subject] || QUIZ_BANK.Matematika) {
    insQuiz.run(classId, q.level, q.question, JSON.stringify(q.options), q.answer);
  }
}

/* ---------- POST /api/auth/classes ---------- */
authRouter.post("/classes", loginLimiter, (req, res) => {
  const { teacherName, className, subject, password } = req.body || {};
  if (!teacherName?.trim() || !className?.trim()) {
    return res.status(400).json({ error: "Ismingiz va sinf nomini kiriting" });
  }
  if (!password || password.trim().length < 8) {
    return res.status(400).json({ error: "Parol kamida 8 belgidan iborat bo'lsin" });
  }

  const code = uniqueClassCode();
  const subj = DEFAULT_LESSONS[subject] ? subject : "Matematika";

  const classId = db.transaction(() => {
    const { lastInsertRowid: id } = db.prepare(
      `INSERT INTO classes (code, name, subject, teacher_name, password_hash, hub_name, hub_next_lab, hub_mentor)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(code, className.trim(), subj, teacherName.trim(), hashPassword(password.trim()),
      "Viloyat markaziy kampusi", "Bu oy ichida", "Tayinlanmagan");
    seedClass(id, subj);
    return id;
  })();

  const token = signToken({ role: "teacher", name: teacherName.trim(), classId, code });
  res.status(201).json({ token, code, class: classView(classId, { includeCodes: true }) });
});

/* ---------- POST /api/auth/teacher ---------- */
authRouter.post("/teacher", loginLimiter, (req, res) => {
  const { code, name, password } = req.body || {};
  const cls = code ? findClassByCode(code.trim().toUpperCase()) : null;
  if (!cls || !password || !checkPassword(password, cls.password_hash)) {
    return res.status(401).json({ error: "Sinf kodi yoki parol noto'g'ri" });
  }
  const token = signToken({ role: "teacher", name: (name || cls.teacher_name).trim(), classId: cls.id, code: cls.code });
  res.json({ token, code: cls.code, class: classView(cls.id, { includeCodes: true }) });
});

/* ---------- POST /api/auth/student/activate ----------
   First login: the student trades the one-time code their teacher gave
   them for a personal password. The code is cleared once used. */
authRouter.post("/student/activate", loginLimiter, (req, res) => {
  const { code, name, joinCode, newPassword } = req.body || {};
  const cls = code ? findClassByCode(code.trim().toUpperCase()) : null;
  const student = cls && name ? findStudent(cls.id, name.trim()) : null;

  const invalid = () => res.status(401).json({ error: "Ism yoki bir martalik kod noto'g'ri" });
  if (!cls || !student || !student.join_code) return invalid();
  if (student.join_code !== (joinCode || "").trim().toUpperCase()) return invalid();
  if (!newPassword || newPassword.length < 6) {
    return res.status(400).json({ error: "Yangi parol kamida 6 belgidan iborat bo'lsin" });
  }

  db.prepare("UPDATE students SET password_hash = ?, join_code = NULL WHERE id = ?")
    .run(hashPassword(newPassword), student.id);

  const token = signToken({ role: "student", name: student.name, classId: cls.id, code: cls.code, studentName: student.name });
  res.json({ token, code: cls.code, class: classView(cls.id) });
});

/* ---------- POST /api/auth/student ---------- */
authRouter.post("/student", loginLimiter, (req, res) => {
  const { code, name, password } = req.body || {};
  const cls = code ? findClassByCode(code.trim().toUpperCase()) : null;
  const student = cls && name ? findStudent(cls.id, name.trim()) : null;

  if (!student) return res.status(401).json({ error: "Ism yoki parol noto'g'ri" });
  if (!student.password_hash) {
    return res.status(409).json({ error: "Hisobingiz hali faollashtirilmagan. O'qituvchingizdan bir martalik kod oling.", needsActivation: true });
  }
  if (!password || !checkPassword(password, student.password_hash)) {
    return res.status(401).json({ error: "Ism yoki parol noto'g'ri" });
  }

  const token = signToken({ role: "student", name: student.name, classId: cls.id, code: cls.code, studentName: student.name });
  res.json({ token, code: cls.code, class: classView(cls.id) });
});

/* ---------- POST /api/auth/parent ----------
   Each family gets its own code, so one parent can't read another
   family's child. */
authRouter.post("/parent", loginLimiter, (req, res) => {
  const { code, name, childName, parentCode } = req.body || {};
  const cls = code ? findClassByCode(code.trim().toUpperCase()) : null;
  const student = cls && childName ? findStudent(cls.id, childName.trim()) : null;

  if (!name?.trim()) return res.status(400).json({ error: "Ismingizni kiriting" });
  if (!student || !student.parent_code || student.parent_code !== (parentCode || "").trim().toUpperCase()) {
    return res.status(401).json({ error: "Farzand ismi yoki ota-ona kodi noto'g'ri" });
  }

  const token = signToken({ role: "parent", name: name.trim(), classId: cls.id, code: cls.code, studentName: student.name });
  res.json({ token, code: cls.code, class: classView(cls.id) });
});

/* ---------- POST /api/auth/admin ---------- */
authRouter.post("/admin", loginLimiter, (req, res) => {
  const { name, password } = req.body || {};
  const expected = process.env.ADMIN_PASSWORD;
  if (!expected) return res.status(500).json({ error: "ADMIN_PASSWORD sozlanmagan" });
  if (!name?.trim() || password !== expected) {
    return res.status(401).json({ error: "Ism yoki parol noto'g'ri" });
  }
  res.json({ token: signToken({ role: "admin", name: name.trim() }) });
});

export { randomCode };
