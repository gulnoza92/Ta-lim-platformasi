export const DEFAULT_LESSONS = {
  Matematika: [
    { title: "Chiziqli tenglamalar", body: "ax + b = 0 ko'rinishidagi tenglama. Misol: 2x + 6 = 0 → x = -3.", guidingQuestion: "Agar a = 0 bo'lsa, tenglamaning yechimi haqida nima deya olamiz?" },
    { title: "Kvadrat tenglamalar", body: "ax² + bx + c = 0. Diskriminant D = b² - 4ac orqali yechim soni aniqlanadi.", guidingQuestion: "Nega D<0 bo'lganda haqiqiy sonlar orasida yechim topilmaydi?" },
    { title: "Foizlar", body: "Foiz — yuzdan ulush. yangi qiymat = eski qiymat × (1 ± foiz/100).", guidingQuestion: "Narx avval 20% oshib, keyin 20% kamaysa, boshlang'ich narxga qaytamizmi?" },
  ],
  Geometriya: [
    { title: "Uchburchak burchaklari", body: "Uchburchakning ichki burchaklari yig'indisi 180°.", guidingQuestion: "Sferada chizilgan 'uchburchak' uchun bu qoida ishlaydimi?" },
    { title: "Pifagor teoremasi", body: "To'g'ri burchakli uchburchakda: a² + b² = c².", guidingQuestion: "Uchburchak to'g'ri burchakli bo'lmasa, formula qanday o'zgaradi?" },
  ],
  Fizika: [
    { title: "Nyutonning ikkinchi qonuni", body: "F = m × a. Misol: 10 kg jismga 20 N kuch → 2 m/s².", guidingQuestion: "Bir xil kuch ikki xil massaga ta'sir qilsa, qaysi biri tezroq tezlanadi?" },
    { title: "Energiya saqlanish qonuni", body: "Yopiq tizimda energiya yo'qolmaydi, bir turdan ikkinchisiga o'tadi.", guidingQuestion: "Mayatnikning eng yuqori nuqtasida qanday energiya ustunlik qiladi?" },
  ],
  "Ona tili": [
    { title: "Ega va kesim", body: "Gapning bosh bo'laklari — ega va kesim.", guidingQuestion: "Egasiz gap bo'lishi mumkinmi? Misol keltiring." },
  ],
};

export const DEFAULT_QUESTIONS = [
  "Uchburchakning ichki burchaklari yig'indisini isbotlang.",
  "500 ning 15% qanchani tashkil qiladi? Yechimingizni tushuntiring.",
];

/** Starter quiz bank per subject. Teachers add their own on top of these. */
export const QUIZ_BANK = {
  Matematika: [
    { level: "oson", question: "5 + 7 = ?", options: ["10", "12", "13", "11"], answer: "12" },
    { level: "oson", question: "9 - 4 = ?", options: ["5", "4", "6", "3"], answer: "5" },
    { level: "orta", question: "12 × 4 = ?", options: ["46", "48", "52", "44"], answer: "48" },
    { level: "orta", question: "144 ni 12 ga bo'lsak?", options: ["11", "12", "13", "14"], answer: "12" },
    { level: "qiyin", question: "x + 15 = 32 bo'lsa, x = ?", options: ["15", "17", "19", "13"], answer: "17" },
    { level: "qiyin", question: "√81 = ?", options: ["7", "8", "9", "10"], answer: "9" },
  ],
  Geometriya: [
    { level: "oson", question: "Uchburchakning nechta tomoni bor?", options: ["2", "3", "4", "5"], answer: "3" },
    { level: "orta", question: "Uchburchak burchaklari yig'indisi?", options: ["90°", "180°", "270°", "360°"], answer: "180°" },
    { level: "qiyin", question: "Katetlari 3 va 4 bo'lsa, gipotenuza?", options: ["5", "6", "7", "12"], answer: "5" },
  ],
  Fizika: [
    { level: "oson", question: "Kuch birligi qanday ataladi?", options: ["Vatt", "Nyuton", "Joul", "Paskal"], answer: "Nyuton" },
    { level: "orta", question: "F = m × a. m=10 kg, F=20 N bo'lsa, a = ?", options: ["0.5 m/s²", "2 m/s²", "200 m/s²", "10 m/s²"], answer: "2 m/s²" },
    { level: "qiyin", question: "Mayatnikning eng yuqori nuqtasida qaysi energiya ustun?", options: ["Kinetik", "Potensial", "Issiqlik", "Yadro"], answer: "Potensial" },
  ],
  "Ona tili": [
    { level: "oson", question: "'Kitob o'qidim' gapida kesim qaysi?", options: ["Kitob", "O'qidim", "Men", "Yo'q"], answer: "O'qidim" },
    { level: "orta", question: "Ega qaysi savolga javob beradi?", options: ["Qanday?", "Kim? Nima?", "Qayerda?", "Qachon?"], answer: "Kim? Nima?" },
    { level: "qiyin", question: "'Kitob' so'zi qaysi turkumga kiradi?", options: ["Fe'l", "Ot", "Sifat", "Ravish"], answer: "Ot" },
  ],
};
