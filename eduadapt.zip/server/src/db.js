import Database from "better-sqlite3";
import fs from "node:fs";
import path from "node:path";

const DB_PATH = process.env.DB_PATH || "./data/eduadapt.db";
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

export const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS classes (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  code          TEXT NOT NULL UNIQUE,
  name          TEXT NOT NULL,
  subject       TEXT NOT NULL,
  teacher_name  TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  hub_name      TEXT DEFAULT '',
  hub_next_lab  TEXT DEFAULT '',
  hub_mentor    TEXT DEFAULT '',
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS students (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  class_id      INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  name          TEXT NOT NULL,
  password_hash TEXT,
  join_code     TEXT,
  parent_code   TEXT,
  mastery       INTEGER NOT NULL DEFAULT 50,
  engagement    INTEGER NOT NULL DEFAULT 0,
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (class_id, name)
);

CREATE TABLE IF NOT EXISTS badges (
  student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  name       TEXT NOT NULL,
  earned_at  TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (student_id, name)
);

CREATE TABLE IF NOT EXISTS mastery_history (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  mastery    INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS home_plans (
  student_id     INTEGER PRIMARY KEY REFERENCES students(id) ON DELETE CASCADE,
  active         INTEGER NOT NULL DEFAULT 0,
  note           TEXT NOT NULL DEFAULT '',
  duration       TEXT NOT NULL DEFAULT 'vaqtinchalik',
  accommodations TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS home_checkins (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  text       TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS lessons (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  class_id         INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  title            TEXT NOT NULL,
  body             TEXT NOT NULL,
  guiding_question TEXT DEFAULT '',
  created_by       TEXT NOT NULL,
  created_at       TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS open_questions (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  class_id INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  text     TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS quiz_questions (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  class_id   INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  level      TEXT NOT NULL CHECK (level IN ('oson','orta','qiyin')),
  question   TEXT NOT NULL,
  options    TEXT NOT NULL,
  answer     TEXT NOT NULL,
  created_by TEXT NOT NULL DEFAULT 'Namuna',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS submissions (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  class_id         INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  student_id       INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  question_id      INTEGER REFERENCES open_questions(id) ON DELETE SET NULL,
  question_text    TEXT NOT NULL,
  answer           TEXT NOT NULL,
  ai_score         INTEGER,
  ai_note          TEXT DEFAULT '',
  guiding_question TEXT DEFAULT '',
  status           TEXT NOT NULL DEFAULT 'kutilmoqda'
                   CHECK (status IN ('kutilmoqda','tasdiqlangan','tahrirlangan')),
  final_score      INTEGER,
  created_at       TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS attendance (
  class_id   INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  day        TEXT NOT NULL,
  status     TEXT NOT NULL CHECK (status IN ('keldi','kelmadi')),
  PRIMARY KEY (class_id, student_id, day)
);

CREATE TABLE IF NOT EXISTS parent_messages (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  class_id      INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  student_id    INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  parent_name   TEXT NOT NULL,
  text          TEXT NOT NULL,
  teacher_reply TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS teacher_cpd (
  class_id  INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  course_id TEXT NOT NULL,
  PRIMARY KEY (class_id, course_id)
);

CREATE INDEX IF NOT EXISTS idx_students_class ON students(class_id);
CREATE INDEX IF NOT EXISTS idx_lessons_class  ON lessons(class_id);
CREATE INDEX IF NOT EXISTS idx_quiz_class     ON quiz_questions(class_id, level);
CREATE INDEX IF NOT EXISTS idx_subs_class     ON submissions(class_id);
CREATE INDEX IF NOT EXISTS idx_attendance_day ON attendance(class_id, day);
CREATE INDEX IF NOT EXISTS idx_messages_class ON parent_messages(class_id);
`);

/* Adds columns that older databases don't have yet, so an existing
   installation keeps its data instead of needing a wipe. */
function ensureColumn(table, column, definition) {
  const cols = db.prepare(`PRAGMA table_info(${table})`).all();
  if (!cols.some((c) => c.name === column)) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
  }
}
ensureColumn("students", "password_hash", "TEXT");
ensureColumn("students", "join_code", "TEXT");
ensureColumn("students", "parent_code", "TEXT");

/* ---------- helpers ---------- */

export const findClassByCode = (code) =>
  db.prepare("SELECT * FROM classes WHERE code = ?").get(code);

export const findStudent = (classId, name) =>
  db.prepare("SELECT * FROM students WHERE class_id = ? AND name = ?").get(classId, name);

function safeJson(s, fallback = {}) {
  try { return JSON.parse(s); } catch { return fallback; }
}

/**
 * Read-only view of a class. Never includes any password hash.
 * Access codes are included only for the teacher (includeCodes).
 */
export function classView(classId, { includeCodes = false } = {}) {
  const cls = db.prepare("SELECT * FROM classes WHERE id = ?").get(classId);
  if (!cls) return null;

  const students = db.prepare("SELECT * FROM students WHERE class_id = ? ORDER BY name").all(classId);
  const badges = db.prepare(
    "SELECT b.student_id, b.name FROM badges b JOIN students s ON s.id = b.student_id WHERE s.class_id = ?"
  ).all(classId);
  const homes = db.prepare(
    "SELECT h.* FROM home_plans h JOIN students s ON s.id = h.student_id WHERE s.class_id = ?"
  ).all(classId);
  const checkIns = db.prepare(
    "SELECT c.student_id, c.text FROM home_checkins c JOIN students s ON s.id = c.student_id WHERE s.class_id = ? ORDER BY c.id"
  ).all(classId);

  const studentMap = {};
  for (const s of students) {
    const home = homes.find((h) => h.student_id === s.id);
    studentMap[s.name] = {
      id: s.id,
      mastery: s.mastery,
      // Whether the student has finished setting up their own password.
      activated: !!s.password_hash,
      ...(includeCodes ? { joinCode: s.join_code, parentCode: s.parent_code } : {}),
      engagement: {
        count: s.engagement,
        badges: badges.filter((b) => b.student_id === s.id).map((b) => b.name),
      },
      home: {
        active: home ? !!home.active : false,
        note: home?.note || "",
        duration: home?.duration || "vaqtinchalik",
        accommodations: home ? safeJson(home.accommodations) : {},
        checkIns: checkIns.filter((c) => c.student_id === s.id).map((c) => c.text),
      },
    };
  }

  const attendance = {};
  for (const r of db.prepare(
    "SELECT a.day, a.status, s.name FROM attendance a JOIN students s ON s.id = a.student_id WHERE a.class_id = ?"
  ).all(classId)) {
    attendance[r.day] = attendance[r.day] || {};
    attendance[r.day][r.name] = r.status;
  }

  return {
    code: cls.code,
    name: cls.name,
    subject: cls.subject,
    teacher: cls.teacher_name,
    hub: { hubName: cls.hub_name, mobileLabNext: cls.hub_next_lab, mentor: cls.hub_mentor },
    content: db.prepare(
      "SELECT id, title, body, guiding_question AS guidingQuestion, created_by AS createdBy FROM lessons WHERE class_id = ? ORDER BY id"
    ).all(classId),
    openQuestions: db.prepare("SELECT id, text FROM open_questions WHERE class_id = ? ORDER BY id").all(classId),
    // The correct answer is deliberately withheld — only the server checks it.
    quizQuestions: db.prepare(
      "SELECT id, level, question, options, created_by AS createdBy FROM quiz_questions WHERE class_id = ? ORDER BY id"
    ).all(classId).map((q) => ({ ...q, options: safeJson(q.options, []) })),
    submissions: db.prepare(
      `SELECT sub.id, s.name AS student, sub.question_id AS questionId, sub.question_text AS questionText,
              sub.answer, sub.ai_score AS aiScore, sub.ai_note AS aiNote,
              sub.guiding_question AS guidingQuestion, sub.status, sub.final_score AS finalScore
       FROM submissions sub JOIN students s ON s.id = sub.student_id
       WHERE sub.class_id = ? ORDER BY sub.id`
    ).all(classId),
    students: studentMap,
    attendance,
    parentMessages: db.prepare(
      `SELECT m.id, m.parent_name AS parentName, s.name AS studentName, m.text, m.teacher_reply AS teacherReply
       FROM parent_messages m JOIN students s ON s.id = m.student_id
       WHERE m.class_id = ? ORDER BY m.id`
    ).all(classId),
    teacherCPD: db.prepare("SELECT course_id FROM teacher_cpd WHERE class_id = ?").all(classId).map((r) => r.course_id),
  };
}
