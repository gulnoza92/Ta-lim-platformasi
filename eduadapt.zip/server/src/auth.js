import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import { findClassByCode } from "./db.js";

const SECRET = process.env.JWT_SECRET;
if (!SECRET || SECRET.length < 16) {
  throw new Error("JWT_SECRET yo'q yoki juda qisqa. .env faylini to'ldiring.");
}

export const hashPassword = (plain) => bcrypt.hashSync(plain, 12);
export const checkPassword = (plain, hash) => bcrypt.compareSync(plain, hash);

export function signToken(payload) {
  return jwt.sign(payload, SECRET, { expiresIn: "12h" });
}

/** Verifies the bearer token and puts the claims on req.user. */
export function requireAuth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: "Avtorizatsiya talab qilinadi" });
  try {
    req.user = jwt.verify(token, SECRET);
    next();
  } catch {
    res.status(401).json({ error: "Sessiya muddati tugagan, qayta kiring" });
  }
}

export function requireRole(...roles) {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ error: "Bu amal uchun huquqingiz yo'q" });
    }
    next();
  };
}

/**
 * Ensures the token's class matches the :code in the URL, so a valid token
 * for class A can never touch class B.
 */
export function requireClassMatch(req, res, next) {
  const cls = findClassByCode(req.params.code);
  if (!cls) return res.status(404).json({ error: "Sinf topilmadi" });
  if (req.user.role !== "admin" && req.user.classId !== cls.id) {
    return res.status(403).json({ error: "Bu sinfga kirish huquqingiz yo'q" });
  }
  req.cls = cls;
  next();
}
